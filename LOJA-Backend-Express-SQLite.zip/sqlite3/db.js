const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./sqlite3/estoque.db');

db.serialize(() => {

  db.run('PRAGMA foreign_keys = ON');

  db.run(`CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    preco REAL,
    foto STRING
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS clientes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    nome         TEXT NOT NULL,
    cpf          TEXT NOT NULL UNIQUE,
    cep          TEXT NOT NULL,
    logradouro   TEXT,
    numero       TEXT,
    complemento  TEXT,
    bairro       TEXT,
    cidade       TEXT,
    estado       TEXT,
    email        TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS funcionarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cargo TEXT
  )`);

  db.run(`
    CREATE TABLE IF NOT EXISTS itens_venda (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      venda_id       INTEGER NOT NULL,
      produto_id     INTEGER NOT NULL,
      quantidade     INTEGER NOT NULL,
      preco_unitario REAL NOT NULL,
      FOREIGN KEY (venda_id)   REFERENCES vendas(id) ON DELETE CASCADE,
      FOREIGN KEY (produto_id) REFERENCES produtos(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS vendas (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      data_venda     DATETIME DEFAULT CURRENT_TIMESTAMP,
      total          REAL NOT NULL,
      pagamento      TEXT,
      desconto       REAL DEFAULT 0,
      funcionario_id INTEGER NOT NULL,
      cliente_id     INTEGER NOT NULL,
      FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id),
      FOREIGN KEY (cliente_id)     REFERENCES clientes(id)
    )
  `);

});

module.exports = db;