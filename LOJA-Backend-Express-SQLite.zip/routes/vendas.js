
const express = require('express');
const router  = express.Router();
const db      = require('../sqlite3/db');

//Schema
db.serialize(() => {
  // Garante integridade referencial
  db.run('PRAGMA foreign_keys = ON');

  db.run(`
    CREATE TABLE IF NOT EXISTS vendas (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      data_venda     DATETIME DEFAULT CURRENT_TIMESTAMP,
      total          REAL NOT NULL,
      pagamento      TEXT,
      desconto       REAL DEFAULT 0,
      funcionario_id INTEGER NOT NULL,
      cliente_id     INTEGER NOT NULL,
      FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id),
      FOREIGN KEY (cliente_id)     REFERENCES clientes(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS itens_venda (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      venda_id       INTEGER NOT NULL,
      produto_id     INTEGER NOT NULL,
      quantidade     INTEGER NOT NULL,
      preco_unitario REAL NOT NULL,
      FOREIGN KEY (venda_id)   REFERENCES vendas(id) ON DELETE CASCADE,
      FOREIGN KEY (produto_id) REFERENCES produtos(id)
    )
  `);
});

router.get('/', (req, res) => {
  db.all('SELECT * FROM vendas', (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message })
    res.json(rows)
  })
})

router.post('/', (req, res) => {
  const { cliente_id, funcionario_id, pagamento, desconto = 0, itens = [] } = req.body;

  if (!Array.isArray(itens) || itens.length === 0) {
    return res.status(400).json({ erro: 'A venda precisa conter ao menos um item.' });
  }

  // Calcula o total a partir dos itens para evitar fraude no front‑end
  const total = itens.reduce((sum, i) => sum + i.quantidade * i.preco_unitario, 0) - desconto;

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    // 1. Insere a venda
    db.run(
      `INSERT INTO vendas (total, pagamento, desconto, funcionario_id, cliente_id)
       VALUES (?, ?, ?, ?, ?)`,
      [total, pagamento, desconto, funcionario_id, cliente_id],
      function (err) {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).json({erro: 'Erro ao inserir venda' + err.message});
        }

        const vendaId = this.lastID;

        // 2. Insere itens + baixa estoque
        const stmtItem = db.prepare(
          `INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario)
           VALUES (?, ?, ?, ?)`
        );

        let erroInterno = null

        for (const { produto_id, quantidade, preco_unitario } of itens) {
          stmtItem.run([vendaId, produto_id, quantidade, preco_unitario], err => {
            if (err) erroInterno =err;
          });
          db.run(
            `UPDATE produtos SET estoque = estoque - ? WHERE id = ?`,
            [quantidade, produto_id], (err) => {
              if (err) erroInterno = err;
            }
          );
        }

        stmtItem.finalize(err => {
          if (err || erroInterno) {
            db.run('ROLLBACK');
            return res.status(500).json({ erro: 'Erro ao inserir itens: '
              +(err?.message || erroInterno?.message) });
          }

          // 3. Commit
          db.run('COMMIT', err => {
            if (err) {
              db.run('ROLLBACK');
              return res.status(500).json({erro: 'Erro no commit:' + err.message});
            }
            res.status(201).json({ vendaId, total });
          });
        });
      }
    );
  });
});

module.exports = router;
