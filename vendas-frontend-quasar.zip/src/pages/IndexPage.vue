<template>
  <q-page class="pagina-inicial">
    <div class="overlay"></div>

    <!-- Conteúdo central -->
    <div class="conteudo">
      <h2 class="text-h4">Bem-vindo à <strong>TechHouse</strong>, Sistema de Vendas</h2>
      <p class="text-subtitle1">Soluções rápidas para suas necessidades em tecnologia.</p>
      <p>Estamos prontos para oferecer o melhor atendimento e suporte técnico para você.</p>
      <q-icon name="fab fa-whatsapp" class="text-green q-mr-sm" />
      <span>Fale conosco</span>
    </div>
  </q-page>
</template>

<script setup>
//
</script>

<style scoped>
.pagina-inicial {
  background-image: url('/imagemcapa.jpg'); /* Use public/ */
  background-size: cover;
  background-position: center;
  position: relative;
  height: 100vh;
  color: white;
  overflow: hidden;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5); /* Escurece a imagem */
  z-index: 1;
}

.conteudo {
  position: relative;
  z-index: 2;
  text-align: center;
  padding: 40px;
  color: #f0f0f0; /* Texto mais claro */
  text-shadow: 1px 1px 2px #000;
}
</style>
