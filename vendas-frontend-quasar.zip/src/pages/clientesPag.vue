<template>
  <q-page class="q-pa-md">
    <q-btn label="Adicionar Cliente" color="primary" @click="adicionarCliente" />
    <q-table :rows="clientes" :columns="columns" row-key="id" class="q-mt-md">
      <template #body-cell-acoes="props">
        <q-td :props="props" class="q-gutter-x-sm">
          <q-btn
            v-if="estaLogado"
            dense
            round
            color="primary"
            icon="edit"
            @click="editarCliente(props.row)"
          />
          <q-btn
            v-if="estaLogado"
            dense
            round
            color="negative"
            icon="delete"
            @click="deletarCliente(props.row.id)"
          />
        </q-td>
      </template>
    </q-table>
    <q-dialog v-model="dialogAtivo">
      <clientesForm
        :cliente="form"
        :modoEdicao="modoEdicao"
        @salvar="salvarCliente"
        @cancelar="dialogAtivo = false"
      />
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from 'boot/axios'
import { useQuasar } from 'quasar'
import clientesForm from 'components/clientesForm.vue'
import autenticar from 'src/autenticar.js'

const estaLogado = autenticar.isAuthenticated()

const $q = useQuasar()
const clientes = ref([])
const dialogAtivo = ref(false)
const modoEdicao = ref(false)

const form = ref({
  id: null,
  nome: '',
  cpf: '',
  cep: '',
  logradouro: '',
  numero: '',
  complemento: '',
  bairro: '',
  cidade: '',
  estado: '',
  email: '',
})

const columns = [
  { name: 'id', label: 'ID', field: 'id', align: 'center' },
  { name: 'nome', label: 'Nome', field: 'nome', align: 'center' },
  { name: 'cpf', label: 'CPF', field: 'cpf', align: 'center' },
  { name: 'cep', label: 'CEP', field: 'cep', align: 'center' },
  { name: 'logradouro', label: 'Logradouro', field: 'logradouro', align: 'center' },
  { name: 'numero', label: 'Numero', field: 'numero', align: 'center' },
  { name: 'complemento', label: 'Complemento', field: 'complemento', align: 'center' },
  { name: 'bairro', label: 'Bairro', field: 'bairro', align: 'center' },
  { name: 'cidade', label: 'Cidade', field: 'cidade', align: 'center' },
  { name: 'estado', label: 'Estado', field: 'estado', align: 'center' },
  { name: 'email', label: 'Email', field: 'email', align: 'center' },
  { name: 'acoes', label: 'Açoes', field: 'acoes', align: 'center' },
]

async function carregarClientes() {
  const res = await api.get('/clientes')
  clientes.value = res.data
}

async function adicionarCliente() {
  modoEdicao.value = false
  form.value = {
    id: null,
    nome: '',
    cpf: '',
    cep: '',
    logradouro: '',
    numero: '',
    complemento: '',
    bairro: '',
    cidade: '',
    estado: '',
    email: '',
  }
  dialogAtivo.value = true
}

function editarCliente(row) {
  modoEdicao.value = true
  form.value = { ...row }
  dialogAtivo.value = true
}

async function salvarCliente(dados) {
  try {
    if (modoEdicao.value) {
      await api.put(`/clientes/${dados.id}`, dados)
    } else {
      await api.post('/clientes', dados)
    }
    $q.notify({
      type: 'positive',
      message: 'Cliente Salvo com sucesso.',
    })
    dialogAtivo.value = false
    await carregarClientes()
  } catch (err) {
    console.error('Erro ao salvar cliente:', err)
    $q.notify({ type: 'negative', message: 'Erro ao salvar cliente.' })
  }
}

async function deletarCliente(id) {
  if (confirm('Excluir este cliente?')) {
    try {
      await api.delete(`/clientes/${id}`)
      await carregarClientes()
      $q.notify({ type: 'positive', message: 'Cliente excluído!' })
    } catch (err) {
      console.error('Erro ao excluir:', err)
      $q.notify({ type: 'negative', message: 'Erro ao excluir cliente.' })
    }
  }
}

onMounted(carregarClientes)
</script>
