const sqlite3 = require('sqlite3').verbose()

const db = new sqlite3.Database('./sqlite3/clientes_test.db');
// Caminho para o banco de testes


module.exports = db
