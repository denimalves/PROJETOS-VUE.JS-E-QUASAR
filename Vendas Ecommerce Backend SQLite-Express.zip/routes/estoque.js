const express = require('express')
const router = express.Router()
const db = require('../sqlite3/db')

router.post('/entrada/:id', (req, res) => {
  const { id, estoque } = req.body

  if (!id || !estoque) {
    return res.status(400).json({ erro: 'Dados incompletos' })
  }

  const sql = `
    UPDATE produtos
    SET estoque = estoque + ?
    WHERE id = ?
  `
  db.run(sql, [estoque, id], function (err) {
    if (err) {
      return res.status(500).json({ erro: 'Erro ao atualizar estoque' })
    }
    res.json({ mensagem: 'Estoque atualizado com sucesso' })
  })
})

module.exports = router
