const express = require('express');
const router = express.Router();
const db = require('../sqlite3/db');

router.get('/', (req, res) => {
  const { inicio, fim, funcionarioId } = req.query;
  const inicioCompleto = `${inicio} 00:00:00`
  const fimCompleto = `${fim} 23:59:59`

  let query = `
    SELECT v.data_venda, v.total, v.pagamento,
           f.nome AS funcionario, c.nome AS cliente
    FROM vendas v
    JOIN funcionarios f ON v.funcionario_id = f.id
    JOIN clientes c ON v.cliente_id = c.id
    WHERE v.data_venda BETWEEN ? AND ?
  `;
  const params = [inicioCompleto, fimCompleto];

  if (funcionarioId) {
    query += ` AND f.id = ?`;
    params.push(funcionarioId);
  }

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

module.exports = router;
