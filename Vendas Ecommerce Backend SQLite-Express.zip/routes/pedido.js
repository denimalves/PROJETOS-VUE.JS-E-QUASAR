const express = require('express')
const router = express.Router()
const db = require('../sqlite3/db') // ajuste o caminho se for diferente

router.get('/', (req, res) => {
  db.all('SELECT * FROM vendas', (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message })
    res.json(rows)
  })
}) 

router.post('/', (req, res) => {
  const { nome, cpf, telefone, pagamento, entrega, endereco, produtos, total, data_venda } = req.body;

  if (!cpf) return res.status(400).json({ erro: 'CPF é obrigatório' });

  if (!Array.isArray(produtos) || produtos.length === 0) {
    return res.status(400).json({ erro: 'A venda precisa conter ao menos um produto.' });
  }

  const enderecoStr = entrega === 'Entrega em domicílio' ? JSON.stringify(endereco) : null;

  db.serialize(() => {
   
    // 1. Buscar cliente por CPF
    db.get(`
      SELECT id FROM clientes WHERE cpf = ?
    `, [cpf], (err, cliente) => {
      if (err) {
        return res.status(500).json({ erro: 'Erro ao buscar cliente: ' + err.message });
      }

      const continuarComClienteId = (clienteId) => {
        // 2. Inserir venda
        db.run('BEGIN TRANSACTION');
        db.run(`
          INSERT INTO vendas (cliente_id, pagamento, entrega, endereco, total, data_venda, funcionario_id)
          VALUES (?, ?, ?, ?, ?, datetime('now'), ?)
        `, [clienteId, pagamento, entrega, enderecoStr, total, 1], function (err) {
          if (err) {
            db.run('ROLLBACK');
            return res.status(500).json({ erro: 'Erro ao salvar venda: ' + err.message });
          }

          const vendaId = this.lastID;

          const insertItem = db.prepare(`
            INSERT INTO itens_venda (venda_id, produto_id, quantidade, nome, preco_unitario)
            VALUES (?, ?, ?, ?, ?)
          `);

          let erroInterno = null;

          for (const item of produtos) {
            const { id: produto_id, nome, preco, quantidade = 1 } = item;

            insertItem.run([vendaId, produto_id, quantidade, nome, preco], (err) => {
              if (err) erroInterno = err;
            });

            db.run(`
              UPDATE produtos SET estoque = estoque - ? WHERE id = ?
            `, [quantidade, produto_id], (err) => {
              if (err) erroInterno = err;
            });
          }

          insertItem.finalize((err) => {
            if (err || erroInterno) {
              db.run('ROLLBACK');
              return res.status(500).json({ erro: 'Erro nos itens: ' + (err?.message || erroInterno?.message) });
            }

            db.run('COMMIT', (err) => {
              if (err) {
                db.run('ROLLBACK');
                return res.status(500).json({ erro: 'Erro no commit: ' + err.message });
              }

              res.status(201).json({ status: 'ok', vendaId });
            });

          });
        });
          
      };

      if (cliente) {
        continuarComClienteId(cliente.id);
      } else {
        return res.status(404).json({ erro: 'Cliente não encontrado com o CPF informado.' });
      }

      
    });
  });
});


module.exports = router
