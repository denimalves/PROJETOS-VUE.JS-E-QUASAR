const express = require('express')
const router = express.Router()
const db = require('../sqlite3/db')

// GET: Lista apenas vendas com entrega em domicílio
router.get('/', (req, res) => {
  db.all(
    `SELECT 
      vendas.id, vendas.data_venda, vendas.pagamento, vendas.entrega,
    json_extract(vendas.endereco, '$.rua') AS rua,
    json_extract(vendas.endereco, '$.numero') AS numero,
    json_extract(vendas.endereco, '$.bairro') AS bairro,
    json_extract(vendas.endereco, '$.cidade') AS cidade,
    vendas.statusEntrega,
    clientes.nome AS cliente, funcionarios.nome AS funcionario
    FROM vendas
    JOIN clientes ON clientes.id = vendas.cliente_id
    JOIN funcionarios ON funcionarios.id = vendas.funcionario_id
    WHERE vendas.entrega = 'Entrega em domicílio'
    ORDER BY vendas.data_venda DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ erro: err.message })
      res.json(rows)
    }
  )
})

router.put('/:id/status', (req, res) => {
  const { id } = req.params
  const { statusEntrega } = req.body

  db.run(
    `UPDATE vendas SET statusEntrega = ? WHERE id = ?`,
    [statusEntrega, id],
    function (err) {
      if (err) return res.status(500).json({ erro: err.message })
      res.json({ sucesso: true })
    }
  )
})

module.exports = router
