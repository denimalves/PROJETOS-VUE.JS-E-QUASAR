const express = require('express');
const router = express.Router();
const db = require('../sqlite3/db');

// Criação da tabela
db.run(`
  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT NOT NULL UNIQUE,
    cep TEXT NOT NULL,
    logradouro TEXT,
    numero TEXT,
    complemento TEXT,
    bairro TEXT,
    cidade TEXT,
    estado TEXT,
    email TEXT,
    telefone TEXT
  )
`);

// Função utilitária para validar campos obrigatórios
function validarCamposObrigatorios(cliente) {
  const { nome, cpf, cep } = cliente;
  return nome && cpf && cep;
}

// GET: Verifica se CPF existe ou lista todos
router.get('/', (req, res) => {
  const { cpf } = req.query;

  if (cpf) {
    db.get('SELECT * FROM clientes WHERE cpf = ?', [cpf], (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      if (row) return res.status(409).json({ msg: 'CPF já cadastrado' });
      return res.status(404).json({ msg: 'CPF disponível' });
    });
  } else {
    db.all('SELECT * FROM clientes', [], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  }
});

// GET: Busca por CPF (rota separada)
router.get('/cpf/:cpf', (req, res) => {
  const { cpf } = req.params;

  db.get('SELECT * FROM clientes WHERE cpf = ?', [cpf], (err, cliente) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!cliente) return res.status(404).json({ error: 'Cliente não encontrado' });
    res.json(cliente);
  });
});

// POST: Cadastra novo cliente
router.post('/', (req, res) => {
  const cliente = req.body;

  if (!validarCamposObrigatorios(cliente))
    return res.status(400).json({ msg: 'Nome, CPF e CEP são obrigatórios' });

  const { cpf } = cliente;

  db.get('SELECT * FROM clientes WHERE cpf = ?', [cpf], (err, existente) => {
    if (err) return res.status(500).json({ msg: 'Erro no servidor' });
    if (existente) return res.status(409).json({ msg: 'CPF já cadastrado' });

    const sql = `
      INSERT INTO clientes (
        nome, cpf, cep, logradouro, numero,
        complemento, bairro, cidade, estado, telefone, email
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
      cliente.nome, cliente.cpf, cliente.cep, cliente.logradouro, cliente.numero,
      cliente.complemento, cliente.bairro, cliente.cidade, cliente.estado,
      cliente.telefone, cliente.email
    ];

    db.run(sql, params, function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ id: this.lastID });
    });
  });
});

// PUT: Atualiza cliente existente
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const cliente = req.body;

  if (!validarCamposObrigatorios(cliente))
    return res.status(400).json({ msg: 'Nome, CPF e CEP são obrigatórios' });

  db.get('SELECT id FROM clientes WHERE cpf = ? AND id != ?', [cliente.cpf, id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (row) return res.status(409).json({ msg: 'CPF já cadastrado para outro cliente' });

    const sql = `
      UPDATE clientes SET
        nome = ?, cpf = ?, cep = ?, logradouro = ?, numero = ?,
        complemento = ?, bairro = ?, cidade = ?, estado = ?, telefone = ?, email = ?
      WHERE id = ?
    `;

    const params = [
      cliente.nome, cliente.cpf, cliente.cep, cliente.logradouro, cliente.numero,
      cliente.complemento, cliente.bairro, cliente.cidade, cliente.estado,
      cliente.telefone, cliente.email, id
    ];

    db.run(sql, params, function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (this.changes === 0)
        return res.status(404).json({ msg: 'Cliente não encontrado' });

      res.json({ msg: 'Cliente atualizado com sucesso' });
    });
  });
});

// DELETE: Remove cliente
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  db.run('DELETE FROM clientes WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0)
      return res.status(404).json({ msg: 'Cliente não encontrado' });

    res.json({ msg: 'Cliente removido com sucesso' });
  });
});

module.exports = router;
