const request = require('supertest')
const express = require('express')
const app = express()
const db = require('../sqlite3/db_test') // banco de testes
const router = require('../routes/clientes')

// Configura app de teste
app.use(express.json())
app.use('/clientes', router)

//cria tabela de clientes para testes
beforeAll(done => {
  db.run(`
    CREATE TABLE IF NOT EXISTS clientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      cpf TEXT UNIQUE NOT NULL,
      cep TEXT NOT NULL,
      logradouro TEXT,
      numero TEXT,
      complemento TEXT,
      bairro TEXT,
      cidade TEXT,
      estado TEXT,
      telefone TEXT,
      email TEXT
    )
  `, done)
})


beforeEach(done => {
  db.serialize(() => {
    db.run('DELETE FROM clientes', () => { //limpa tabela antes de cada teste
      db.run('DELETE FROM sqlite_sequence WHERE name="clientes"', done) // zera o autoincremento também
    })
  })
})


describe('API /clientes - Testes de Integração', () => {

  // it('Deve retornar lista vazia de clientes inicialmente', async () => {
  //   const res = await request(app).get('/clientes')
  //   expect(res.statusCode).toBe(200)
  //   expect(res.body).toEqual([])
  // })

  it('Deve cadastrar um cliente com sucesso', async () => {
    const cliente = {
      nome: 'Maria Teste',
      cpf: '12345678900',
      cep: '01001000',
      logradouro: 'Rua das Flores',
      numero: '123',
      complemento: '',
      bairro: 'Centro',
      cidade: 'São Paulo',
      estado: 'SP',
      email: 'maria@teste.com',
      telefone: '11999999999'
    }

    const res = await request(app).post('/clientes').send(cliente)
    expect(res.statusCode).toBe(201)
    expect(res.body).toHaveProperty('id')
  })

  it('Deve retornar erro ao cadastrar cliente com CPF duplicado', async () => {
    const cliente = {
      nome: 'João Teste',
      cpf: '11111111111',
      cep: '01002000',
      logradouro: 'Rua 2',
      numero: '456',
      bairro: 'Bairro',
      cidade: 'Cidade',
      estado: 'SP',
      email: 'joao@teste.com',
      telefone: '1188888888'
    }

    await request(app).post('/clientes').send(cliente)
    const res = await request(app).post('/clientes').send(cliente)

    expect(res.statusCode).toBe(409)
    expect(res.body.msg).toMatch(/CPF já cadastrado/)
  })

  it('Deve retornar cliente pelo CPF', async () => {
    const cliente = {
      nome: 'Maria',
      cpf: '11111111111',
      cep: '37925000',
      logradouro: '',
      numero: '',
      bairro: '',
      cidade: '',
      estado: '',
      telefone: '',
      email: ''
    }

    await request(app).post('/clientes').send(cliente)
    const res = await request(app).get('/clientes/cpf/11111111111')

    expect(res.statusCode).toBe(200)
    expect(res.body.nome).toBe('Maria')
  })

  it('Deve retornar erro se faltar campos obrigatórios', async () => {
    const res = await request(app).post('/clientes').send({
      cpf: '99999999999',
      cep: '12345678'
    })

    expect(res.statusCode).toBe(400)
    expect(res.body.msg).toMatch(/Nome, CPF e CEP/i)
  })

})

