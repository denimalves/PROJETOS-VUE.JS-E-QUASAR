<template>
  <q-page padding> <h5>HISTÓRICO DE VENDAS EM MANUTENÇÃO</h5> </q-page>
</template>

<script setup>
//
</script>
