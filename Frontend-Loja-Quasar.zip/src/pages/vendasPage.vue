<template>
  <q-page class="q-pa-md">
    <q-card class="q-pa-lg q-mx-auto" style="max-width: 900px">
      <q-card-section>
        <div class="text-h5">Registrar Venda</div>
      </q-card-section>

      <q-separator inset />

      <q-card-section>
        <VendaForm
          :funcionarios="funcionarios"
          :clientes="clientes"
          :produtos="produtos"
          @salvar="salvarVenda"
        />
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref } from 'vue'
import { api } from 'boot/axios'
import { useQuasar } from 'quasar'
import VendaForm from 'components/vendaForm.vue'

const $q = useQuasar()

// Dados carregados do backend
const funcionarios = ref([])
const clientes = ref([])
const produtos = ref([])

async function carregarReferencias() {
  {
    const [f, c, p] = await Promise.all([
      api.get('/funcionarios'),
      api.get('/clientes'),
      api.get('/produtos'),
    ])
    funcionarios.value = f.data
    clientes.value = c.data
    produtos.value = p.data
  }
}

carregarReferencias()

async function salvarVenda(payload) {
  try {
    const { data } = await api.post('/vendas', payload)
    $q.notify({ type: 'positive', message: `Venda #${data.vendaId} registrada!` })
  } catch (e) {
    $q.notify({ type: 'negative', message: e.response?.data?.erro || 'Falha ao registrar venda' })
  }
}
</script>
