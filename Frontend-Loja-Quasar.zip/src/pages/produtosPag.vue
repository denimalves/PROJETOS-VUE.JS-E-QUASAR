<template>
  <q-page class="q-pa-md">
    <q-btn label="Adicionar Produto" color="primary" @click="abrirDialog" />

    <q-table :rows="produtos" :columns="colunas" row-key="id" class="q-mt-md" flat>
      <template v-slot:body-cell-foto="props">
        <q-td>
          <q-img :src="props.row.foto" :alt="props.row.nome" style="width: 80px; height: 80px" />
        </q-td>
      </template>
      <template #body-cell-acoes="props">
        <q-td :props="props" class="q-gutter-x-sm">
          <q-btn dense round color="primary" icon="edit" @click="editarProduto(props.row)" />
          <q-btn dense round color="negative" icon="delete" @click="deletarProduto(props.row.id)" />
        </q-td>
      </template>
    </q-table>

    <q-dialog v-model="dialog">
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">
            {{ modoEdicao ? 'Editar Produto' : 'Novo Produto' }}
          </div>
        </q-card-section>

        <q-card-section class="q-gutter-md">
          <q-input v-model="produto.nome" label="Nome" />
          <q-input v-model.number="produto.preco" label="Preço" type="number" />
          <q-input v-model="produto.foto" label="URL da Foto" />
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="negative" v-close-popup />
          <q-btn flat label="Salvar" color="primary" @click="salvarProduto" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from 'boot/axios'
import { useQuasar } from 'quasar'
const $q = useQuasar()

const produtos = ref([])
const dialog = ref(false)
const modoEdicao = ref(false) // false = novo | true = edição
const produto = ref({
  nome: '',
  preco: 0,
  foto: '',
})

const colunas = [
  { name: 'id', label: 'ID', field: 'id', align: 'center' },
  { name: 'nome', label: 'Nome', field: 'nome', align: 'center' },
  { name: 'preco', label: 'Preço', field: 'preco', align: 'center' },
  { name: 'foto', label: 'Foto', field: 'foto', align: 'center' },
  { name: 'acoes', label: 'Açoes', field: 'acoes', align: 'center' },
]

const carregarProdutos = async () => {
  const response = await api.get('/produtos')
  produtos.value = response.data
}

const salvarProduto = async () => {
  try {
    if (!produto.value.nome || !produto.value.preco) {
      $q.notify({ type: 'warning', message: 'Preencha nome e preço.' })
      return
    }

    if (modoEdicao.value) {
      await api.put(`/produtos/${produto.value.id}`, produto.value)
    } else {
      await api.post('/produtos', produto.value)
    }
    $q.notify({
      type: 'positive',
      message: 'Produto Salvo com sucesso.',
    })

    dialog.value = false
    await carregarProdutos()
  } catch (error) {
    console.error('Erro ao salvar produto:', error)
    $q.notify({
      type: 'negative',
      message: 'Erro ao salvar produto. Verifique os dados e o servidor.',
    })
  }
}

const abrirDialog = () => {
  modoEdicao.value = false
  produto.value = { id: null, nome: '', preco: 0, foto: '' }
  dialog.value = true
}

const editarProduto = (row) => {
  modoEdicao.value = true
  produto.value = { ...row } // clona a linha selecionada
  dialog.value = true
}

const deletarProduto = async (id) => {
  if (confirm('Tem certeza que deseja excluir?')) {
    await api.delete(`/produtos/${id}`)
    $q.notify({
      type: 'positive',
      message: 'Produto Excluido com sucesso.',
    })
    await carregarProdutos()
  }
}
onMounted(() => {
  carregarProdutos()
})
</script>
