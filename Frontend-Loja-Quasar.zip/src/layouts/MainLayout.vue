<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn flat dense round icon="menu" aria-label="Menu" @click="toggleLeftDrawer" />

        <q-toolbar-title> Vendas TECHouse </q-toolbar-title>

        <div>Desenvolvido por Denner Alves Victoria's Tecnologia</div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <q-list>
        <q-item-label header>
          <q-avatar size="100px" class="q-mb-sm">
            <img src="../assets/logovictoriasmobile.png" />
          </q-avatar>
        </q-item-label>

        <EssentialLink v-for="link in linksList" :key="link.title" v-bind="link" />
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script setup>
import { ref } from 'vue'
import EssentialLink from 'components/EssentialLink.vue'

const linksList = [
  {
    title: 'home',
    caption: 'Retornar Página Inicial',
    icon: 'home',
    to: '/',
  },
  {
    title: 'Produtos',
    caption: 'Consultar Produtos',
    icon: 'inventory',
    to: '/produtos',
  },
  {
    title: 'Venda',
    caption: 'Acesso a Venda',
    icon: 'shopping_cart',
    to: '/vendas',
  },
  {
    title: 'Historico de Vendas',
    caption: 'Visualize as vendas Realizadas',
    icon: 'list_alt',
    to: '/historicoVendas',
  },
  {
    title: 'Clientes',
    caption: 'Acesso para clientes',
    icon: 'groups',
    to: '/clientes',
  },
  {
    title: 'Funcionarios',
    caption: 'Acesso para Funcionários',
    icon: 'badge',
    to: '/funcionarios',
  },
  {
    title: 'Desenvolvedor',
    caption: 'Conheça os Projetos do Desenvolvedor',
    icon: 'code',
    href: 'https://github.com/denimalves',
  },
]

const leftDrawerOpen = ref(false)

function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value
}
</script>
