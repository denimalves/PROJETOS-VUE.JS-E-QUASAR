<template>
  <q-card style="min-width: 350px">
    <q-card-section>
      <div class="text-h6">{{ modoEdicao ? 'Editar Cliente' : 'Novo Cliente' }}</div>
    </q-card-section>

    <q-card-section class="q-gutter-md">
      <q-input v-model="formLocal.nome" label="Nome" filled dense />
      <q-input
        v-model="formLocal.cpf"
        label="CPF"
        filled
        dense
        :error="cpfDuplicado"
        error-message="CPF já cadastrado"
        maxlength="11"
      />
      <q-input v-model="formLocal.cep" label="CEP" filled dense maxlength="8" />
      <q-input v-model="formLocal.logradouro" label="Logradouro" filled dense />
      <q-input v-model="formLocal.numero" label="Numero" filled dense />
      <q-input v-model="formLocal.complemento" label="Complemento" filled dense />
      <q-input v-model="formLocal.bairro" label="Bairro" filled dense />
      <q-input v-model="formLocal.cidade" label="Cidade" filled dense />
      <q-input v-model="formLocal.estado" label="Estado" filled dense />
      <q-input v-model="formLocal.email" label="Email" filled dense type="email" />
    </q-card-section>

    <q-card-actions align="right">
      <q-btn flat label="Cancelar" @click="$emit('cancelar')" />
      <q-btn flat label="Salvar" color="primary" @click="emitirSalvar" />
    </q-card-actions>
  </q-card>
</template>

<script setup>
import { ref, watch } from 'vue'
import { useQuasar } from 'quasar'
import { api } from 'boot/axios' // seu backend
import axios from 'axios' // para chamar ViaCEP
import debounce from 'lodash/debounce'

const $q = useQuasar()

const props = defineProps({
  cliente: Object,
  modoEdicao: Boolean,
})

const emit = defineEmits(['salvar', 'cancelar'])

const formLocal = ref({
  nome: '',
  cpf: '',
  cep: '',
  logradouro: '',
  numero: '',
  complemento: '',
  bairro: '',
  cidade: '',
  estado: '',
  email: '',
})

watch(
  () => props.cliente,
  (novo) => {
    formLocal.value = { ...novo }
  },
  { immediate: true },
)

const cpfDuplicado = ref(false)
const verificandoCpf = ref(false)

const checarCpf = debounce(async () => {
  const { cpf } = formLocal.value
  if (!cpf) {
    cpfDuplicado.value = false
    return
  }

  try {
    verificandoCpf.value = true
    await api.get(`/clientes?cpf=${cpf}`) // backend deve filtrar por cpf
    // se voltar um cliente diferente do atual -> duplicado
    cpfDuplicado.value = true
  } catch (err) {
    // 404 = ok (cpf livre), 409 = duplicado
    cpfDuplicado.value = err.response?.status === 409
  } finally {
    verificandoCpf.value = false
  }
}, 300)

watch(() => formLocal.value.cpf, checarCpf)

const buscarCep = debounce(async () => {
  const { cep } = formLocal.value
  if (!cep || cep.length < 8) return

  try {
    const { data } = await axios.get(`https://viacep.com.br/ws/${cep}/json/`)
    if (data.erro) throw new Error('CEP inválido')
    formLocal.value.logradouro = data.logradouro
    formLocal.value.bairro = data.bairro
    formLocal.value.cidade = data.localidade
    formLocal.value.estado = data.uf
  } catch {
    $q.notify({ type: 'warning', message: 'CEP não encontrado.' })
  }
}, 300)

watch(() => formLocal.value.cep, buscarCep)

function emitirSalvar() {
  if (cpfDuplicado.value) {
    $q.notify({ type: 'negative', message: 'CPF já cadastrado!' })
    return
  }

  if (!formLocal.value.nome || !formLocal.value.cpf || !formLocal.value.cep) {
    alert('Preencha todos os campos')
    return
  }
  emit('salvar', { ...formLocal.value })
}
</script>
