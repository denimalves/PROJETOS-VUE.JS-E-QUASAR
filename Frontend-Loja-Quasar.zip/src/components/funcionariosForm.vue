<template>
  <q-card style="min-width: 300px">
    <q-card-section>
      <div class="text-h6">{{ modoEdicao ? 'Editar Funcionário' : 'Novo Funcionário' }}</div>
    </q-card-section>

    <q-card-section>
      <q-input v-model="formLocal.nome" label="Nome" filled dense />
      <q-input v-model="formLocal.cargo" label="Cargo" filled dense class="q-mt-sm" />
    </q-card-section>

    <q-card-actions align="right">
      <q-btn flat label="Cancelar" @click="$emit('cancelar')" />
      <q-btn flat label="Salvar" color="primary" @click="emitirSalvar" />
    </q-card-actions>
  </q-card>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  funcionario: Object,
  modoEdicao: Boolean,
})
const emit = defineEmits(['salvar', 'cancelar'])

const formLocal = ref({ nome: '', cargo: '' })

watch(
  () => props.funcionario,
  (novo) => {
    formLocal.value = { ...novo }
  },
  { immediate: true },
)

function emitirSalvar() {
  if (!formLocal.value.nome || !formLocal.value.cargo) {
    alert('Preencha todos os campos')
    return
  }
  emit('salvar', { ...formLocal.value })
}
</script>
