const express = require('express');
const router = express.Router();
const db = require('../sqlite3/db');

db.run(`
CREATE TABLE IF NOT EXISTS consertos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cliente TEXT NOT NULL,
  contato TEXT,
  aparelho TEXT NOT NULL,
  imei TEXT NOT NULL UNIQUE,
  defeito TEXT NOT NULL,
  status TEXT,
  valor_estimado REAL,
  valor_final REAL,
  tecnico TEXT,
  data_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,
  data_entrega DATETIME,
  FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
)`);

router.get('/', (req, res) => {
  db.all(`
    SELECT 
      c.*, 
      f.nome AS tecnico 
    FROM consertos c 
    LEFT JOIN funcionarios f ON c.funcionario_id = f.id
  `, (err, rows) => {
    if (err) {
      res.status(500).json({ erro: err.message });
    } else {
      res.json(rows);
    }
  })
});

// [GET] Um conserto por ID
router.get('/:id', (req, res) => {
  const { id } = req.params
  db.get('SELECT * FROM consertos WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message })
    if (!row) return res.status(404).json({ erro: 'Conserto não encontrado' })
    res.json(row)
  })
})

// [GET] Verificar se IMEI já existe
router.get('/imei/:imei', (req, res) => {
  const { imei } = req.params
  const sql = 'SELECT id FROM consertos WHERE imei = ?'

  db.get(sql, [imei], (err, row) => {
    if (err) {
      console.error('Erro ao verificar IMEI:', err)
      return res.status(500).json({ erro: 'Erro ao verificar IMEI' })
    }
    if (row) {
          res.json({ existe: true, id: row.id })
        } else {
          res.json({ existe: false })
        }
  })
})

// [POST] Criar novo conserto
router.post('/', (req, res) => {
  const {
    cliente,
    contato,
    aparelho,
    imei,
    defeito,
    status,
    valor_estimado,
    valor_final,
    tecnico,
    data_entrega,
    funcionario_id
  } = req.body

  db.run(`
    INSERT INTO consertos
    (cliente, contato, aparelho, imei, defeito, status, valor_estimado, valor_final, tecnico, data_entrega, funcionario_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [cliente,  contato, aparelho, imei, defeito, status, valor_estimado, valor_final, tecnico, data_entrega, funcionario_id], function (err) {
    if (err) return res.status(500).json({ erro: err.message })
    res.json({ id: this.lastID })
  })
})

// [PUT] Atualizar conserto
router.put('/:id', (req, res) => {
  const { id } = req.params
  const {
    cliente,
    contato,
    aparelho,
    imei,
    defeito,
    status,
    valor_estimado,
    valor_final,
    tecnico,
    data_entrega,
    funcionario_id
  } = req.body

  db.run(`
    UPDATE consertos SET
      cliente = ?,
      contato = ?,
      aparelho = ?,
      imei = ?,
      defeito = ?,
      status = ?,
      valor_estimado = ?,
      valor_final = ?,
      tecnico = ?,
      data_entrega = ?,
      funcionario_id = ?
    WHERE id = ?
  `, [cliente, contato, aparelho, imei, defeito, status, valor_estimado, valor_final, tecnico, data_entrega, funcionario_id, id], function (err) {
    if (err) return res.status(500).json({ erro: err.message })
    res.json({ alterado: this.changes > 0 })
  })
})

// [DELETE] Excluir conserto
router.delete('/:id', (req, res) => {
  const { id } = req.params
  db.run('DELETE FROM consertos WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ erro: err.message })
    res.json({ deletado: this.changes > 0 })
  })
})


module.exports = router;
