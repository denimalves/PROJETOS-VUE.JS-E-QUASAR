const express = require('express');
const cors = require('cors');
const db = require('./sqlite3/db');

const app = express();
app.use(cors());
app.use(express.json());

const produtosRoutes = require('./routes/produtos');
const clientesRoutes = require('./routes/clientes');
const funcionariosRoutes = require('./routes/funcionarios');
const vendasRoutes = require('./routes/vendas');
const estoqueRoutes = require('./routes/estoque');
const relatorioRoutes = require('./routes/relatorio');
const pedidoRoutes = require('./routes/pedido');
const entregasRoutes = require('./routes/entregas');
const consertosRoutes = require('./routes/consertos');

app.use('/produtos', produtosRoutes);
app.use('/clientes', clientesRoutes);
app.use('/funcionarios', funcionariosRoutes);
app.use('/vendas', vendasRoutes);
app.use('/estoque', estoqueRoutes);
app.use('/relatoriovendas', relatorioRoutes);
app.use('/pedido', pedidoRoutes);
app.use('/entregas', entregasRoutes);
app.use('/consertos', consertosRoutes);

app.listen(3000, '0.0.0.0', () => {
  console.log('API rodando em http://localhost:3000');
});