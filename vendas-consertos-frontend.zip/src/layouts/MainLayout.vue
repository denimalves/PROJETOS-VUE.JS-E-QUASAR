<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn flat dense round icon="menu" aria-label="Menu" @click="toggleLeftDrawer" />

        <q-toolbar-title align="center"> VENDAS TECHHOUSE </q-toolbar-title>
        <div v-if="usuario">
          <q-btn flat icon="person" label="Bem vindo," /> {{ usuario.nome }}
          <q-btn flat icon="logout" @click="logout" />
        </div>
      </q-toolbar>
    </q-header>
    <q-footer>
      <div align="right">Desenvolvido por Denner Alves Victoria's Tecnologia</div>
    </q-footer>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <q-list>
        <q-item-label header>
          <q-avatar size="100px" class="q-mb-sm">
            <img src="../assets/logovictoriasmobile.png" />
          </q-avatar>
        </q-item-label>

        <EssentialLink v-for="link in linksList" :key="link.title" v-bind="link" />
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script setup>
import { ref, computed } from 'vue'
import EssentialLink from 'components/EssentialLink.vue'
import autenticar from 'src/autenticar.js'
import { useRouter } from 'vue-router'

const router = useRouter()

const usuario = computed(() => autenticar.getUsuario())

function logout() {
  autenticar.logout()
  router.push({ name: 'login' }) // volta pra tela de login
}

const linksList = computed(() => {
  const publico = ['home', 'Comprar', 'Carrinho', 'consertos', 'Login']

  return [
    {
      title: 'home',
      caption: 'Retornar Página Inicial',
      icon: 'home',
      to: '/',
    },

    {
      title: 'consertos',
      caption: 'Cadastre o seu aparelho para conserto. Buscamos em Domicílio',
      icon: 'build',
      to: '/consertos',
    },
    {
      title: 'Listagem Consertos',
      caption: 'Listagem de Consertos para acompanhamento ',
      icon: 'list',
      to: '/listagemConsertos',
    },
    {
      title: 'Comprar',
      caption: 'Acesso a tela de Compras',
      icon: 'shopping_cart',
      to: '/vitrine',
    },
    {
      title: 'Carrinho',
      caption: 'Acesso ao Carrinho de Compras',
      icon: 'shopping_basket',
      to: '/carrinho',
    },
    {
      title: 'Login',
      caption: 'Acesso a tela de login',
      icon: 'login',
      to: '/login',
    },

    {
      title: 'Produtos',
      caption: 'Consultar Produtos',
      icon: 'inventory',
      to: '/produtos',
    },
    {
      title: 'Estoque',
      caption: 'Entrada de Produtos, acesso restrito',
      icon: 'inventory',
      to: '/atualizarestoque',
    },
    {
      title: 'Venda',
      caption: 'Clique para efetuar uma Venda, acesso restrito',
      icon: 'shopping_cart',
      to: '/vendas',
    },
    {
      title: 'Historico de Vendas',
      caption: 'Vendas Realizadas, acesso restrito',
      icon: 'list_alt',
      to: '/historicoVendas',
    },
    {
      title: 'Entregas',
      caption: 'Consultar Entregas em Domicílio',
      icon: 'local_shipping',
      to: '/entregas',
    },
    {
      title: 'Clientes',
      caption: 'Clique para Cadastrar clientes',
      icon: 'groups',
      to: '/clientes',
    },
    {
      title: 'Vendedores',
      caption: 'Vendedores Cadastrados, acesso restrito',
      icon: 'badge',
      to: '/funcionarios',
    },
    {
      title: 'Desenvolvedor',
      caption: 'Conheça os Projetos do Desenvolvedor',
      icon: 'code',
      href: 'https://github.com/denimalves',
    },
  ].filter((link) => {
    // Mostrar apenas "home", "Comprar", "Carrinho" e "Login" para quem não está logado
    if (!usuario.value) {
      return publico.includes(link.title)
    }
    // Ocultar "Login" se já estiver logado
    if (usuario.value && link.title === 'Login') return false

    return true // usuário logado: mostrar tudo (menos Login)
  })
})

const leftDrawerOpen = ref(false)

function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value
}
</script>
