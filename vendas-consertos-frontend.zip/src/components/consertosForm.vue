<template>
  <q-card flat bordered class="q-pa-md" style="max-width: 600px; margin: auto">
    <div class="text-h6 q-mb-md">🔧 Ordem de Conserto</div>

    <q-form @submit.prevent="handleSubmit" ref="formRef" class="q-gutter-md">
      <q-input
        v-model="formLocal.cliente"
        label="Cliente"
        filled
        :rules="[(val) => !!val || 'Cliente é obrigatório']"
        lazy-rules
      />
      <q-input
        v-model="formLocal.contato"
        label="Contato"
        filled
        :rules="[(val) => !!val || 'Contato é obrigatório']"
        lazy-rules
        mask="(##) #####-####"
      />

      <q-input
        v-model="formLocal.aparelho"
        label="Aparelho"
        filled
        :rules="[(val) => !!val || 'Aparelho é obrigatório']"
        lazy-rules
      />

      <q-input
        v-model="formLocal.imei"
        label="IMEI"
        filled
        dense
        :rules="[(val) => !!val || 'IMEI é obrigatório']"
        lazy-rules
        @blur="verificarImei()"
      />

      <q-input
        v-model="formLocal.defeito"
        label="Defeito"
        filled
        type="textarea"
        :rules="[(val) => !!val || 'Defeito é obrigatório']"
        lazy-rules
      />

      <q-select
        v-if="isAuthenticated"
        v-model="formLocal.status"
        :options="['Aguardando Analise', 'Em conserto', 'Pronto', 'Entregue']"
        label="Status"
        filled
      />

      <q-input
        v-if="isAuthenticated"
        v-model.number="formLocal.valor_estimado"
        label="Valor Estimado"
        prefix="R$"
        type="number"
        filled
      />

      <q-input
        v-if="isAuthenticated"
        v-model.number="formLocal.valor_final"
        label="Valor Final"
        prefix="R$"
        type="number"
        filled
      />

      <q-input
        v-if="isAuthenticated"
        v-model="formLocal.data_entrega"
        label="Data de Entrega"
        type="datetime-local"
        filled
      />

      <q-select
        v-if="isAuthenticated"
        v-model="formLocal.funcionario_id"
        :options="funcionarios"
        option-value="id"
        option-label="nome"
        label="Técnico Responsável"
        filled
        dense
        clearable
        emit-value
        map-options
      />

      <div class="row justify-end q-gutter-sm q-mt-md">
        <q-btn flat label="Cancelar" color="negative" @click="$emit('cancelar')" />
        <q-btn type="submit" label="Salvar" color="primary" />
      </div>
    </q-form>
  </q-card>
</template>

<script setup>
import { computed, ref, watch, onMounted } from 'vue'
import autenticar from 'src/autenticar.js'
import { api } from '../boot/axios.js'
import { useQuasar } from 'quasar'

const isAuthenticated = autenticar.isAuthenticated()
//const clientes = ref([])
const funcionarios = ref([])
const $q = useQuasar()

const props = defineProps({
  modelValue: {
    type: Object,
    required: true,
  },
})

const emit = defineEmits(['update:modelValue', 'salvo', 'cancelar'])

const formRef = ref(null)

// Criar cópia local do form para edição sem alterar props diretamente
const formLocal = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val),
})
// Sincroniza quando o modelValue externo muda
watch(
  () => props.modelValue,
  (newVal) => {
    formLocal.value = { ...newVal }
  },
  { deep: true },
)

// Método chamado ao enviar o formulário
const handleSubmit = () => {
  formRef.value.validate().then((valid) => {
    if (valid) {
      emit('update:modelValue', formLocal.value)
      emit('salvo', formLocal.value)
    }
  })
}

// async function carregarClientes() {
//   try {
//     const { data } = await api.get('/clientes')
//     clientes.value = data
//   } catch {
//     $q.notify({ type: 'negative', message: 'Erro ao carregar clientes' })
//   }
// }

async function carregarFuncionarios() {
  const { data } = await api.get('/funcionarios')
  console.log('Funcionários carregados:', data)
  funcionarios.value = data
}

async function verificarImei() {
  const imei = formLocal.value.imei
  const id = formLocal.value.id // só existe se for edição
  if (!imei) return // Se não tiver IMEI, não faz nada
  try {
    const { data } = await api.get(`/consertos/imei/${imei}`)
    if (!data) return // Se não encontrar, não faz nada
    console.log('Resposta do IMEI:', data)

    if (data.existe && data.id !== id) {
      $q.notify({ type: 'negative', message: '⚠️ IMEI já está cadastrado em outro conserto!' })
      formLocal.value.imei = ''
    }
  } catch (err) {
    console.error('Erro ao verificar IMEI:', err)
    $q.notify({
      type: 'negative',
      message: err?.response?.data?.message || 'Erro ao verificar IMEI',
    })
  }
}

onMounted(() => {
  //carregarClientes()
  carregarFuncionarios()
})
</script>
