<template>
  <q-card-section>
    <consertosForm
      :model-value="formLocal"
      @cancelar="limparFormulario"
      @salvo="salvarFormulario"
    />
  </q-card-section>
</template>

<script setup>
import { ref } from 'vue'
import consertosForm from 'src/components/consertosForm.vue'
import { api } from 'boot/axios'

const formLocal = ref({
  cliente: '',
  contato: '',
  aparelho: '',
  imei: '',
  defeito: '',
  status: 'Aguardando Analise',
  valor_estimado: '',
  valor_final: '',

  funcionario_id: null,
})

const limparFormulario = () => {
  formLocal.value = {
    cliente: '',
    contato: '',
    aparelho: '',
    imei: '',
    defeito: '',
    status: 'Aguardando Analise',
    valor_estimado: '',
    valor_final: '',
    funcionario_id: null,
  }
}

const salvarFormulario = async () => {
  try {
    await api.post('/consertos', formLocal.value)
    limparFormulario()
  } catch (error) {
    console.error('Erro ao salvar:', error)
  }
}
</script>
