<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md" align="center">🔧 Controle de Consertos</div>
    <q-form @submit.prevent="filtrarConsertos">
      <div class="q-gutter-sm row items-center">
        <q-select
          v-model="filtros.status"
          :options="statusOptions"
          label="Status"
          dense
          filled
          clearable
          style="width: 100px"
          class="q-py-sm"
        />
        <q-select
          v-model="filtros.tecnico"
          :options="funcionariosOptions"
          label="Técnico"
          dense
          filled
          clearable
          style="width: 120px"
          class="q-py-sm"
        />
        <q-input
          v-model="filtros.data_entrada"
          type="date"
          label="Data de Entrada"
          dense
          filled
          clearable
        />
        <q-btn label="Filtrar" type="submit" color="primary" />
        <q-btn label="Limpar" flat @click="limparFiltros" />
        <q-btn
          label="Gerar Relatorio"
          color="secondary"
          @click="gerarRelatorioPDF"
          class="q-ml-auto"
        />
      </div>
    </q-form>
    <q-dialog v-model="dialogAberto">
      <consertosForm :model-value="formlocal" @cancelar="fecharDialog" @salvo="salvarConserto" />
    </q-dialog>

    <q-card style="min-width: 500px"> </q-card>
    <q-table :rows="consertos" :columns="colunas" row-key="id" class="q-mt-md" flat bordered>
      <template v-slot:body-cell-data_entrada="props">
        <q-td :props="props">
          {{ formatarDataHora(props.row.data_entrada) }}
        </q-td>
      </template>
      <template v-slot:body-cell-actions="props">
        <q-td align="center">
          <q-btn flat icon="print" @click="gerarPDFOS(props.row.id)" />
          <q-btn flat icon="edit" color="primary" @click="editarConserto(props.row)" />
          <q-btn flat icon="delete" color="negative" @click="removerConserto(props.row.id)" />
        </q-td>
      </template>
    </q-table>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import jsPDF from 'jspdf'
import { api } from '../boot/axios'
import autoTable from 'jspdf-autotable'
import consertosForm from 'src/components/consertosForm.vue'

const consertos = ref([])
//const dialog = ref(false)
const formlocal = ref({
  cliente: '',
  contato: '',
  aparelho: '',
  imei: '',
  defeito: '',
  status: 'Aguardando Analise',
  valor_estimado: '',
  valor_realizado: '',
  tecnico: '',
  funcionario_id: '',
})

const colunas = [
  { name: 'id', label: 'O.S', field: 'id', align: 'center' },
  { name: 'cliente', label: 'Cliente', field: 'cliente', align: 'center' },
  { name: 'contato', label: 'Contato', field: 'contato', align: 'center' },
  { name: 'defeito', label: 'Defeito', field: 'defeito', align: 'center' },
  { name: 'status', label: 'Status', field: 'status', align: 'center' },
  { name: 'tecnico', label: 'Técnico', field: 'tecnico', align: 'center' },
  { name: 'data_entrada', label: 'Data de Entrada', field: 'data_entrada', align: 'center' },

  { name: 'actions', label: 'Ações', field: 'actions', align: 'center', sortable: false },
]

const filtros = ref({
  status: null,
  tecnico: null,
  funcionario_id: null,
  data_entrada: null,
})

const statusOptions = ['Aguardando Analise', 'Em conserto', 'Pronto', 'Entregue']
const funcionariosOptions = ref([])

onMounted(() => {
  buscarFuncionarios()
  buscarConsertos()
})

const buscarFuncionarios = async () => {
  try {
    const { data } = await api.get('/funcionarios')
    funcionariosOptions.value = data.map((f) => f.nome)
  } catch (error) {
    console.error('Erro ao buscar funcionários', error)
  }
}

const buscarConsertos = async () => {
  try {
    const { data } = await api.get('/consertos') // ou ajuste para buscar filtrado
    consertos.value = data
  } catch (error) {
    console.error('Erro ao buscar consertos:', error)
  }
}

const filtrarConsertos = () => {
  let filtrados = [...consertos.value]

  if (filtros.value.status) {
    filtrados = filtrados.filter((c) => c.status === filtros.value.status)
  }
  if (filtros.value.tecnico) {
    filtrados = filtrados.filter((c) => c.tecnico === filtros.value.tecnico)
  }
  if (filtros.value.data_entrada) {
    filtrados = filtrados.filter((c) => c.data_entrada?.startsWith(filtros.value.data_entrada))
  }

  consertos.value = filtrados
}

const limparFiltros = () => {
  filtros.value = {
    status: null,
    tecnico: null,
    funcionario_id: null,
    data_entrada: null,
  }
  buscarConsertos()
}

const carregarConsertos = async () => {
  const { data } = await api.get('/consertos')
  consertos.value = data
}

const gerarPDFOS = async (id) => {
  try {
    const { data } = await api.get(`/consertos/${id}`)

    const pdf = new jsPDF('p', 'mm', 'a4')
    const margemX = 14
    let y = 20

    // Cabeçalho
    pdf.setFontSize(16)
    pdf.text(`Ordem de Serviço Número: ${data.id}`, 105, 15, { align: 'center' })

    pdf.setFontSize(12)
    const linhas = [
      [`Cliente:`, data.cliente],
      [`Contato:`, data.contato],
      [`Aparelho:`, data.aparelho],
      [`IMEI:`, data.imei || '—'],
      [`Defeito:`, data.defeito],
      [`Status:`, data.status],
      [`Valor Est.:`, `R$ ${parseFloat(data.valor_estimado).toFixed(2)}`],
      [`Valor Final:`, `R$ ${parseFloat(data.valor_final).toFixed(2)}`],
      [`Técnico:`, data.tecnico || '—'],
      [`Entrada:`, formatarDataHora(data.data_entrada)],
      [`Entrega:`, formatarDataHora(data.data_entrega)],
    ]

    // Tabela simples (jspdf‑autotable)
    autoTable(pdf, {
      startY: y,
      headStyles: { fillColor: [240, 240, 240] },
      theme: 'grid',
      margin: { left: margemX },
      styles: { cellPadding: 2, fontSize: 11 },
      body: linhas.map(([k, v]) => [k, String(v)]),
    })

    pdf.save(`OS_${id}.pdf`)
  } catch (err) {
    console.error('Erro ao gerar PDF:', err)
  }
}

const gerarRelatorioPDF = () => {
  if (consertos.value.length === 0) {
    alert('Nenhum conserto disponível para gerar o relatório.')
    return
  }

  const dataAtual = new Date().toISOString().slice(0, 10)
  const doc = new jsPDF('p', 'mm', 'a4')
  doc.setFontSize(16)
  doc.text('Relatório de Consertos', 105, 15, { align: 'center' })
  doc.text(formatarDataHora(dataAtual), 200, 15, { align: 'right' })

  const headers = ['O.S', 'Cliente', 'Contato', 'Defeito', 'Status', 'Técnico', 'Data de Entrada']

  const body = consertos.value.map((c) => [
    c.id,
    c.cliente,
    c.contato || '—',
    c.defeito,
    c.status,
    c.tecnico || '—',
    formatarDataHora(c.data_entrada),
  ])

  autoTable(doc, {
    startY: 25,
    head: [headers],
    body,
    styles: { fontSize: 10 },
    headStyles: { fillColor: [60, 141, 188] }, // azul
    theme: 'striped',
    margin: { left: 10, right: 10 },
  })

  doc.save(`relatorio_consertos_${formatarDataHora(dataAtual)}.pdf`)
}

function formatarDataHora(dataStr) {
  if (!dataStr) return '—'

  const data = new Date(dataStr)
  if (isNaN(data)) return '—'

  const dia = String(data.getDate()).padStart(2, '0')
  const mes = String(data.getMonth() + 1).padStart(2, '0')
  const ano = data.getFullYear()
  const horas = String(data.getHours()).padStart(2, '0')
  const minutos = String(data.getMinutes()).padStart(2, '0')

  return `${dia}/${mes}/${ano} ${horas}:${minutos}`
}

const dialogAberto = ref(false)
const editandoId = ref(null) // guarda o ID quando estiver editando

function editarConserto(consertos) {
  formlocal.value = { ...consertos }
  editandoId.value = consertos.id
  dialogAberto.value = true
}

function fecharDialog() {
  dialogAberto.value = false
}

async function salvarConserto(dados) {
  try {
    if (editandoId.value) {
      await api.put(`/consertos/${editandoId.value}`, dados)
    }
    await carregarConsertos()
    fecharDialog()
  } catch (error) {
    console.error('Erro ao salvar:', error)
  }
}

async function removerConserto(id) {
  const confirmar = confirm('Deseja realmente excluir este conserto?')
  if (confirmar) {
    try {
      await api.delete(`/consertos/${id}`)
      await carregarConsertos()
    } catch (error) {
      console.error('Erro ao excluir:', error)
    }
  }
}

onMounted(() => {
  carregarConsertos()
})
</script>

<style scoped>
#pdf-content {
  font-family: Arial, sans-serif;
  font-size: 12px;
  line-height: 1.4;
}

.pdf-container {
  position: absolute;
  top: -9999px;
  left: -9999px;
  width: 210mm; /* largura A4 */
  padding: 20px;
  background: white;
  visibility: visible; /* importante */
}
</style>
