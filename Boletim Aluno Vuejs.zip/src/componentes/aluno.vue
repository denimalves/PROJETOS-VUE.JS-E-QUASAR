<!--Script-->
<script setup>
import { computed, onMounted, ref, } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css';

let alunos = ref ([]);

let filtro = ref ([]);

const filtroalunos = computed(() => {

    if(alunos.value && filtro.value){
        return alunos.value.filter(alunos => alunos.nomeAluno
        
        .includes(filtro.value)
    )
    }
    return alunos.value;
})


onMounted(() => {
    fetch("http://localhost:3000/alunos")
    .then((requisicao) => requisicao.json())
    .then((retorno) => (alunos.value = retorno))

});

let obj = ref ({ })

function cadastrar (event) {
    fetch("http://localhost:3000/alunos", {
        method: 'POST',
        body: JSON.stringify(obj.value),
        headers: { 'Content-Type' : 'aplication/json'},
    })
    .then((requisicao) => requisicao.json())
    .then((retorno) => {
        alunos.value.push(retorno)
    })

    obj.value.nomeAluno = ""
    obj.value.nota01 = ""
    obj.value.nota02 = ""
    
    event.preventDefault()
}

function Selecionar(indice) {
    obj.value = {
        id: alunos.value[indice].id,
        nomeAluno: alunos.value[indice].nomeAluno,
        nota01: alunos.value[indice].nota01,
        nota02: alunos.value[indice].nota02
    }
}

function editar () {
    fetch(`http://localhost:3000/alunos/${obj.value.id}`, {
        method: "PUT",
        body: JSON.stringify(obj.value),
        headers: { "Content-Type" : "aplication/json" },
    })
    .then((requisicao) => requisicao.json())
    .then((retorno) => {
        let indicealunos = alunos.value.findIndex((objP) => {
            return objP.id === retorno.id
        })
        alunos.value[indicealunos] = retorno
    })


    obj.value.nomeAluno = ""
    obj.value.nota01 = ""
    obj.value.nota02 = ""
}

function remover() {
    fetch(`http://localhost:3000/alunos/${obj.value.id}`, {
        method: "DELETE",
        headers: {"Content-Type": "aplication/json" },
    })
    .then((requisicao) => requisicao.json())
    .then(() => {
        let indicealunos = alunos.value.findIndex((objP) => {
            return objP.id === obj.value.id
        })
        alunos.value.splice(indicealunos, 1);
    })

    obj.value.nomeAluno = ""
    obj.value.nota01 = ""
    obj.value.nota02 = ""
}

function filtrar() {
   return alunos.value.filter(obj => obj.nomeAluno
   
   .includes(filtro.value));}

       
       
      
</script>


<!--CSS-->
<style>
form {
  width: 25%;
  margin: 30px auto;
  text-align: center;
}

input {
  margin-bottom: 10px;
}

.espacamentoBtn {
  margin-left: 5px;
  margin-right: 5px;
}

.pesquisa{
    margin-top: 30px;
}
</style>

<!--HTML-->
<template>

<div>
    <h1 align="center">Cadastrar Notas</h1>
    <form @submit="cadastrar">
       <div>

            <input type="text" placeholder="nome" class="form-control" v-model="obj.nomeAluno" required>
            <input type="number" placeholder="nota01" class="form-control" v-model="obj.nota01" min="0" max="10">
            <input type="number" placeholder="nota02" class="form-control" v-model="obj.nota02" min="0" max="10">

            <input type="submit" value="Cadastrar" class="btn btn-primary">
            <input type="button" @click="editar" value="Editar" class="btn btn-primary">
            <input type="button" @click="remover" value="Remover" class="btn btn-primary">
        </div>
    </form>

    <div class="row">
        <h2>Confira o boletim dos alunos</h2>
        <div class="col-12">
            <input type="text" v-model="filtro" placeholder="Qual nome você deseja filtrar?"
            name="inputFiltro" class="form-control pesquisa">
            <p v-if="filtrar().length == 0 ">Não foi encontrado nenhum aluno</p>
            <p v-else-if="filtrar().length == 1 ">Foi encontrado apenas um aluno</p>
            <p v-else>Foram encontrados {{ filtrar().length }} Alunos.</p>

        </div>
    </div>
</div>



<!--Tabela-->
<table class="table table-strip">
    <thead>
       <tr>
        <th>ID</th>
        <th>Nome do Aluno</th>
        <th>Nota 01</th>
        <th>Nota 02</th>
        <th>Media</th>
        <th>Situação</th>
        <th>Selecionar</th>
       </tr>
    </thead>
        <tbody >
            <tr v-for="(a, indice) in filtroalunos">
                
                <td>{{a.id }}</td>
                <td>{{ a.nomeAluno }}</td>
                <td>{{ a.nota01 }}</td>
                <td>{{ a.nota02 }}</td>
                <td>{{ ((a.nota01+a.nota02)/2) }}</td>
                <td v-if= "((a.nota01+a.nota02)/2) >=7">Aprovado(a)</td>
                <td v-else-if= "((a.nota01+a.nota02)/2) >=5">Em Exame</td>
                <td v-else= "((a.nota01+a.nota02)/2) <5">Reprovado(a)</td>
                <td><button @click="Selecionar(indice)" class="btn btn-primary">Selecionar</button></td>

            </tr>
        </tbody>
</table>
<footer align="right" position="bottom">
    Desenvolvido por Denner Cunha Alves, Victoria's Mobile.
</footer>
</template>