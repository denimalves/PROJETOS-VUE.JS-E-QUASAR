<script setup>
import { createRouter, createWebHistory } from 'vue-router'


</script>

<template>
  <header>
    <div class="p-3 mb-2 bg-success text-white" >
      
    <img alt="Vue logo" class="logo" src="@/static/logovictoriasmobile.png" width="125" height="125" />

        <RouterLink class="corlink" to="/" >Home</RouterLink> | 
        <RouterLink class="corlink" to="/alunos">Aluno</RouterLink><hr>

        <h1 ALIGN="CENTER">BOLETIM DO ALUNO</h1>

    </div>
  </header>


  <RouterView />
</template>

<style>

.corlink {

  color: white;

}
</style>
