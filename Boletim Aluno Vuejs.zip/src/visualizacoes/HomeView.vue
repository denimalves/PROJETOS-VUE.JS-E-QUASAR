<script setup>
import 'bootstrap/dist/css/bootstrap.min.css';
</script>

<!--CSS---->
<style>

.site-footer {
  background: gray;
  text-align: right;
  color: white;
}

.boletim {
  width: 30%;
  height: 30%;
  margin: 10px, auto;

}
</style>

<template>

      <h1>Pagina Inicial</h1>
      <img alt="Vue boletim" class="boletim" src="@/static/boletim.jpg" />

    <footer class="site-footer">
      <p>Desenvolvido por Denner Cunha Alves, Victoria's Mobile.</p>
    </footer>
 
</template>
