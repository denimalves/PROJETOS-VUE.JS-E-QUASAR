const express = require('express');
const router = express.Router();
const db = require('../sqlite3/db');

router.get('/', (req, res) => {
  db.all('SELECT * FROM funcionarios', [], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

router.post('/', (req, res) => {
  const { nome, cargo } = req.body;
  db.run('INSERT INTO funcionarios (nome, cargo) VALUES (?, ?)', [nome, cargo], function (err) {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: this.lastID });
  });
});

router.put('/:id', (req, res) => {
  const { id }      = req.params;
  const { nome, cargo } = req.body;

  if (!nome || !cargo)
    return res.status(400).json({ msg: 'Nome e cargo são obrigatórios' });

  db.run(
    'UPDATE funcionarios SET nome = ?, cargo = ? WHERE id = ?',
    [nome, cargo, id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (this.changes === 0)
        return res.status(404).json({ msg: 'Funcionário não encontrado' });
      res.json({ msg: 'Funcionário atualizado com sucesso' });
    }
  );
});

router.delete('/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM funcionarios WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0)
      return res.status(404).json({ msg: 'Funcionário não encontrado' });
    res.json({ msg: 'Funcionário removido com sucesso' });
  });
});


module.exports = router;