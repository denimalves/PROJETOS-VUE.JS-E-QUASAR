const express = require('express')
const router = express.Router()
const db = require('../sqlite3/db')

db.run(`CREATE TABLE IF NOT EXISTS produtos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  preco REAL,
  estoque INTEGER,
  foto TEXT
)`)

router.get('/', (req, res) => {
  db.all('SELECT * FROM produtos', (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message })
    res.json(rows)
  })
})

router.get('/:id', (req, res) => {
  const { id } = req.params
  db.get('SELECT * FROM produtos WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message })
    if (!row) return res.status(404).json({ erro: 'Produto não encontrado' })
    res.json(row)
  })
})

router.post('/', (req, res) => {
  const { nome, preco, estoque, foto } = req.body
  if (!nome || preco === undefined) {
    return res.status(400).json({ erro: 'Nome e preço são obrigatórios' })
  }

  db.run(
    'INSERT INTO produtos (nome, preco, estoque, foto) VALUES (?, ?, ?, ?)',
    [nome, preco, estoque, foto],
    function (err) {
      if (err) return res.status(500).json({ erro: err.message })
      res.status(201).json({ id: this.lastID, nome, preco, foto })
    }
  )
})

router.put('/:id', (req, res) => {
  const { id } = req.params
  const { nome, preco, estoque, foto } = req.body

  db.run(
    'UPDATE produtos SET nome = ?, preco = ?, estoque = ?, foto = ? WHERE id = ?',
    [nome, preco, foto, id],
    function (err) {
      if (err) return res.status(500).json({ erro: err.message })
      if (this.changes === 0) {
        return res.status(404).json({ erro: 'Produto não encontrado' })
      }
      res.json({ id, nome, preco, estoque, foto })
    }
  )
})

router.delete('/:id', (req, res) => {
  const { id } = req.params

  db.run('DELETE FROM produtos WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ erro: err.message })
    if (this.changes === 0) {
      return res.status(404).json({ erro: 'Produto não encontrado' })
    }
    res.json({ mensagem: 'Produto excluído com sucesso' })
  })
})

module.exports = router
