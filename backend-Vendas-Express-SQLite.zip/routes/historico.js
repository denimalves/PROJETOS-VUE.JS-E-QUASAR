const express = require('express');
const router = express.Router();
const db = require('../sqlite3/db');

router.get('/', (req, res) => {
  const sql = `
    SELECT v.id, v.data, v.total, v.pagamento, v.desconto, c.nome as cliente
    FROM vendas v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ORDER BY v.data DESC
  `;
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  const id = req.params.id;
  const vendaSql = `SELECT * FROM vendas WHERE id = ?`;
  const itensSql = `
    SELECT iv.*, p.nome FROM itens_venda iv
    JOIN produtos p ON iv.produto_id = p.id WHERE iv.venda_id = ?
  `;

  db.get(vendaSql, [id], (err, venda) => {
    if (err) return res.status(500).json(err);
    if (!venda) return res.status(404).json({ erro: 'Venda não encontrada' });

    db.all(itensSql, [id], (err, itens) => {
      if (err) return res.status(500).json(err);
      res.json({ venda, itens });
    });
  });
});

module.exports = router;