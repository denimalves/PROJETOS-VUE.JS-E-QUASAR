// routes/clientes.js
const express = require('express')
const router  = express.Router()
const db      = require('../sqlite3/db')

/* ------------------------------------------------------------------ *
 *  Cria a tabela (se não existir)                                    *
 * ------------------------------------------------------------------ */
db.run(`
  CREATE TABLE IF NOT EXISTS clientes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    nome         TEXT NOT NULL,
    cpf          TEXT NOT NULL UNIQUE,
    cep          TEXT NOT NULL,
    logradouro   TEXT,
    numero       TEXT,
    complemento  TEXT,
    bairro       TEXT,
    cidade       TEXT,
    estado       TEXT,
    email        TEXT
  )
`)

/* ------------------------------------------------------------------ *
 *  [GET] /clientes  → lista todos                                    *
 * ------------------------------------------------------------------ */
router.get('/', (req, res) => {
  const { cpf } = req.query
  if (cpf) {
    db.get('SELECT * FROM clientes WHERE cpf = ?', [cpf], (err, row) => {
      if (err) return res.status(500).json({ error: err.message })
      if (row) return res.status(409).json({ msg: 'CPF já cadastrado' })
      return res.status(404).json({ msg: 'CPF disponível' })
    })
  } else {
  db.all('SELECT * FROM clientes', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message })
    res.json(rows)
  })
  }
})


/* ------------------------------------------------------------------ *
 *  [POST] /clientes  → cria novo cliente                             *
 * ------------------------------------------------------------------ */
router.post('/', (req, res) => {
  const {
    nome, cpf, cep, logradouro,
    numero, complemento, bairro,
    cidade, estado, email
  } = req.body

  if (!nome || !cpf || !cep)
    return res.status(400).json({ msg: 'Nome, CPF e cep' })

  const sql = `
    INSERT INTO clientes (
      nome, cpf, cep, logradouro, numero,
      complemento, bairro, cidade, estado, email
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `
  const params = [nome, cpf, cep, logradouro, numero, complemento, bairro, cidade, estado, email]

  db.run(sql, params, function (err) {
    if (err) {
      if (err.code === 'SQLITE_CONSTRAINT') {
        return res.status(409).json({ msg: 'CPF já cadastrado' })
      }
      return res.status(500).json({ error: err.message })
    }
    res.status(201).json({ id: this.lastID })
  })
})

/* ------------------------------------------------------------------ *
 *  [PUT] /clientes/:id  → atualiza cliente                           *
 * ------------------------------------------------------------------ */
router.put('/:id', (req, res) => {
  const { id } = req.params
  const {
    nome, cpf, cep, logradouro,
    numero, complemento, bairro,
    cidade, estado, email
  } = req.body

  if (!nome || !cpf || !cep)
    return res.status(400).json({ msg: 'Nome, CPF e cep são obrigatórios' })

  // Primeiro verifica se CPF já existe em outro cliente
  db.get('SELECT id FROM clientes WHERE cpf = ? AND id != ?', [cpf, id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message })
    if (row) return res.status(409).json({ msg: 'CPF já cadastrado para outro cliente' })
      
  const sql = `
    UPDATE clientes SET
      nome = ?, cpf = ?, cep = ?, logradouro = ?, numero = ?,
      complemento = ?, bairro = ?, cidade = ?, estado = ?, email = ?
    WHERE id = ?
  `
  const params = [
    nome, cpf, cep, logradouro, numero,
    complemento, bairro, cidade, estado, email, id
  ]

  db.run(sql, params, function (err) {
    if (err) {
      if (err.code === 'SQLITE_CONSTRAINT') {
        return res.status(409).json({ msg: 'CPF já cadastrado para outro cliente' })
      }
      return res.status(500).json({ error: err.message })
    }
    if (this.changes === 0)
      return res.status(404).json({ msg: 'Cliente não encontrado' })
    res.json({ msg: 'Cliente atualizado com sucesso' })
  })
})

/* ------------------------------------------------------------------ *
 *  [DELETE] /clientes/:id  → remove cliente                          *
 * ------------------------------------------------------------------ */
router.delete('/:id', (req, res) => {
  const { id } = req.params
  db.run('DELETE FROM clientes WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: err.message })
    if (this.changes === 0)
      return res.status(404).json({ msg: 'Cliente não encontrado' })
    res.json({ msg: 'Cliente removido com sucesso' })
  })
})
})

module.exports = router
