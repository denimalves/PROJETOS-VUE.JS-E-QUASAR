const express = require('express');
const cors = require('cors');
const db = require('./sqlite3/db');

const app = express();
app.use(cors());
app.use(express.json());

const produtosRoutes = require('./routes/produtos');
const clientesRoutes = require('./routes/clientes');
const funcionariosRoutes = require('./routes/funcionarios');
const vendasRoutes = require('./routes/vendas');

app.use('/produtos', produtosRoutes);
app.use('/clientes', clientesRoutes);
app.use('/funcionarios', funcionariosRoutes);
app.use('/vendas', vendasRoutes);

app.listen(3000, () => {
  console.log('API rodando em http://localhost:3000');
});