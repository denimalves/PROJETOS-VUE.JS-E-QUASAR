const { defineConfig } = require('cypress')

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:9000', // Porta do frontend Quasar
    supportFile: 'cypress/support/e2e.js',
    specPattern: 'cypress/e2e/loja.cy.js',
  },
})
