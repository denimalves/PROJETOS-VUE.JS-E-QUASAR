const routes = [
  {
    path: '',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', name: '', component: () => import('pages/IndexPage.vue') },
      {
        path: '/produtos',
        component: () => import('pages/produtosPag.vue'),
        meta: { requiresAuth: true },
      },
      { path: '/clientes', component: () => import('pages/clientesPag.vue') },
      {
        path: '/funcionarios',
        component: () => import('pages/funcionariosPag.vue'),
        meta: { requiresAuth: true },
      },
      {
        path: '/vendas',
        component: () => import('pages/vendasPage.vue'),
        meta: { requiresAuth: true },
      },
      {
        path: '/historicoVendas',
        component: () => import('pages/historicoVendas.vue'),
        meta: { requiresAuth: true },
      },
      {
        path: '/atualizarestoque',
        name: 'atualizarestoque',
        component: () => import('pages/atualizarEstoque.vue'),
        meta: { requiresAuth: true },
      },
      {
        path: '/vitrine',
        component: () => import('pages/vitrineOnline.vue'),
      },
      {
        path: '/carrinho',
        component: () => import('pages/carrinhoOnline.vue'),
      },
      {
        path: '/checkout',
        component: () => import('pages/checkOut.vue'),
      },
      {
        path: '/entregas',
        component: () => import('pages/entregasDomicilio.vue'),
        meta: { requiresAuth: true },
      },

      { path: '/login', name: 'login', component: () => import('pages/loginUsuario.vue') },
    ],
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue'),
  },
]

export default routes
