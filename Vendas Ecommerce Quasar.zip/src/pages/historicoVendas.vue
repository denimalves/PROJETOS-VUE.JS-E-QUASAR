<template>
  <q-page class="q-pa-md">
    <q-card class="q-pa-lg q-mx-auto" style="max-width: 1000px">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h5">Histórico de Vendas</div>
        <q-space />
        <q-input
          dense
          outlined
          v-model="filtro"
          placeholder="Filtrar por Vendedor ou pagamento"
          debounce="400"
          style="width: 300px"
          clearable
        >
          <template #prepend>
            <q-icon name="search" />
          </template>
        </q-input>
      </q-card-section>

      <q-separator class="q-my-md" />

      <q-table
        :loading="loading"
        :columns="columns"
        :rows="rowsFiltradas"
        row-key="id"
        flat
        dense
        @row-click="(evt, row) => abrirDetalhes(row)"
      >
        <template #body-cell-total="props">
          <q-td :props="props"> R$ {{ props.row.total.toFixed(2) }} </q-td>
        </template>
        <template #body-cell-data="props">
          <q-td :props="props">
            {{ formatarData(props.row.data) }}
          </q-td>
        </template>
      </q-table>
    </q-card>

    <!-- Dialog de detalhes -->
    <q-dialog v-model="dialogDetalhes" persistent maximized>
      <q-card style="max-width: 700px; width: 100%">
        <q-card-section class="row items-center q-pb-none">
          <div class="text-h6">Código da Venda: {{ detalhes.venda?.id }}</div>
          <q-space />
          <q-btn dense flat icon="close" v-close-popup />
        </q-card-section>

        <q-card-section>
          <q-list bordered separator>
            <q-item>
              <q-item-section avatar><q-icon name="event" /></q-item-section>
              <q-item-section>Data</q-item-section>
              <q-item-section side>{{ formatarData(detalhes.venda?.data) }}</q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar><q-icon name="people" /></q-item-section>
              <q-item-section>Cliente</q-item-section>
              <q-item-section side>{{ detalhes.venda?.cliente }}</q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar><q-icon name="people" /></q-item-section>
              <q-item-section>Vendedor</q-item-section>
              <q-item-section side>{{ detalhes.venda?.funcionarios }}</q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar><q-icon name="payments" /></q-item-section>
              <q-item-section>Forma de pagamento</q-item-section>
              <q-item-section side>{{ detalhes.venda?.pagamento }}</q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar><q-icon name="local_offer" /></q-item-section>
              <q-item-section>Desconto</q-item-section>
              <q-item-section side>R$ {{ detalhes.venda?.desconto.toFixed(2) }}</q-item-section>
            </q-item>
            <q-item>
              <q-item-section avatar><q-icon name="attach_money" /></q-item-section>
              <q-item-section>Total</q-item-section>
              <q-item-section side>R$ {{ detalhes.venda?.total.toFixed(2) }}</q-item-section>
            </q-item>
          </q-list>

          <div class="text-subtitle1 q-mt-md">Itens</div>
          <q-markup-table flat bordered dense>
            <thead>
              <tr>
                <th>Produto</th>
                <th class="text-right">Qtd</th>
                <th class="text-right">Preço unit.</th>
                <th class="text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="it in detalhes.itens" :key="it.id">
                <td>{{ it.nome }}</td>
                <td class="text-right">{{ it.quantidade }}</td>
                <td class="text-right">R$ {{ it.preco_unitario.toFixed(2) }}</td>
                <td class="text-right">R$ {{ (it.quantidade * it.preco_unitario).toFixed(2) }}</td>
              </tr>
            </tbody>
          </q-markup-table>
        </q-card-section>
      </q-card>
    </q-dialog>

    <!-- gerar relatorio -->
    <div class="q-pa-md">
      <div class="row q-gutter-sm items-end">
        <q-input
          v-model="filtrorelatorio.inicio"
          type="date"
          label="Início"
          filled
          dense
          style="width: 150px"
        />

        <q-input
          v-model="filtrorelatorio.fim"
          type="date"
          label="Fim"
          filled
          dense
          style="width: 150px"
        />

        <q-select
          v-model="filtrorelatorio.funcionarioId"
          :options="funcionarios"
          option-label="nome"
          option-value="id"
          emit-value
          map-options
          label="Vendedor"
          filled
          dense
          clearable
          style="width: 180px"
        />

        <q-btn label="Gerar PDF" color="primary" icon="picture_as_pdf" @click="gerarRelatorioPDF" />
      </div>
    </div>
  </q-page>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { api } from 'boot/axios'
import { useQuasar, date } from 'quasar'
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'

const $q = useQuasar()
const loading = ref(true)
const vendas = ref([])
const filtro = ref('')
const dialogDetalhes = ref(false)
const detalhes = ref({ venda: null, itens: [] })

const columns = [
  { name: 'id', label: '#', field: 'id', align: 'left', sortable: true },
  { name: 'data', label: 'Data', field: 'data', align: 'left', sortable: true },
  { name: 'cliente', label: 'Cliente', field: 'cliente', align: 'left', sortable: true },
  {
    name: 'funcionario',
    label: 'Vendedor',
    field: 'funcionario',
    align: 'left',
    sortable: true,
  },
  { name: 'pagamento', label: 'Pagamento', field: 'pagamento', align: 'left', sortable: true },
  {
    name: 'desconto',
    label: 'Desconto',
    field: 'desconto',
    align: 'right',
    format: (val) => `R$ ${val.toFixed(2)}`,
  },
  { name: 'total', label: 'Total', field: 'total', align: 'right', sortable: true },
]

const filtrorelatorio = ref({
  inicio: '',
  fim: '',
  funcionarioId: null,
})

const funcionarios = ref([])

function formatarData(iso) {
  return date.formatDate(iso, 'DD/MM/YYYY HH:mm')
}

const rowsFiltradas = computed(() => {
  if (!filtro.value) return vendas.value
  const f = filtro.value.toLowerCase()
  return vendas.value.filter(
    (r) =>
      String(r.funcionario).toLowerCase().includes(f) ||
      String(r.pagamento).toLowerCase().includes(f),
  )
})

async function carregarVendas() {
  try {
    const { data } = await api.get('/vendas')
    vendas.value = data
  } catch {
    $q.notify({ type: 'negative', message: 'Erro ao carregar vendas' })
  } finally {
    loading.value = false
  }
}

async function abrirDetalhes(row) {
  try {
    const { data } = await api.get(`/vendas/${row.id}`)
    detalhes.value = data

    dialogDetalhes.value = true
  } catch (e) {
    $q.notify({ type: 'negative', message: e.response?.data?.erro || 'Erro ao carregar detalhes' })
  }
}

async function carregarFuncionarios() {
  const res = await api.get('/funcionarios')
  funcionarios.value = res.data
}

async function gerarRelatorioPDF() {
  const { inicio, fim, funcionarioId } = filtrorelatorio.value

  if (!inicio || !fim) {
    $q.notify({ type: 'warning', message: 'Informe as datas de início e fim' })
    return
  }

  const { data } = await api.get('/relatoriovendas', {
    params: { inicio, fim, funcionarioId },
  })

  const doc = new jsPDF()
  doc.text('Relatório de Vendas', 14, 15)
  doc.setFontSize(10)

  const dataInicioBR = new Date(inicio + 'T00:00:00').toLocaleDateString('pt-BR')
  const dataFimBR = new Date(fim + 'T00:00:00').toLocaleDateString('pt-BR')

  doc.text(`Período: ${dataInicioBR} até ${dataFimBR}`, 14, 22)

  // Soma dos totais
  const totalGeral = data.reduce((acc, venda) => acc + venda.total, 0)

  autoTable(doc, {
    startY: 28,
    head: [['Data', 'Cliente', 'Vendedor', 'Pagamento', 'Total']],
    body: data.map((v) => [
      new Date(v.data_venda).toLocaleDateString('pt-BR'),
      v.cliente,
      v.funcionario,
      v.pagamento,
      `R$ ${v.total.toFixed(2)}`,
    ]),
  })

  // Mostra total no fim do relatório
  const vfinal = doc.lastAutoTable.finalY || 40
  doc.setFontSize(12)
  doc.text(`Total Geral: R$ ${totalGeral.toFixed(2)}`, 14, vfinal + 10)

  doc.save('relatorio_vendas.pdf')
}

onMounted(carregarVendas)

onMounted(carregarFuncionarios)
</script>
