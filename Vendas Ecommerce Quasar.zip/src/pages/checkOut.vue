<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">🧾 Finalizar Pedido</div>

    <q-form @submit.prevent="enviarPedido">
      <q-input
        v-model="nome"
        label="Nome completo"
        filled
        dense
        class="q-mb-md"
        :rules="[(val) => !!val || 'Informe o nome']"
        :disable="nomeBloqueado"
      />
      <q-input
        v-model="cpf"
        label="CPF"
        filled
        dense
        class="q-mb-md"
        mask="###.###.###-##"
        :rules="[(val) => !!val || 'Informe o CPF']"
        @blur="buscarCliente"
      />
      <q-banner
        v-if="mensagemCliente"
        :class="clienteEncontrado ? 'bg-green-2 text-green-10' : 'bg-orange-2 text-orange-10'"
        class="q-mb-md"
      >
        {{ mensagemCliente }}
        <q-btn
          v-if="!clienteEncontrado"
          label="Cadastrar cliente"
          color="primary"
          flat
          dense
          @click="router.push('/clientes')"
        />
      </q-banner>
      <q-input
        v-model="telefone"
        label="Telefone / WhatsApp"
        filled
        dense
        class="q-mb-md"
        mask="(##) #####-####"
        :rules="[(val) => !!val || 'Informe o telefone']"
      />

      <q-select
        v-model="entrega"
        label="Tipo de Entrega"
        filled
        dense
        class="q-mb-md"
        :options="['Retirada na loja', 'Entrega em domicílio']"
        :rules="[(val) => !!val || 'Escolha uma opção']"
      />

      <!-- Endereço aparece apenas se entrega for domicílio -->
      <div v-if="entrega === 'Entrega em domicílio'" class="q-gutter-md q-mb-md">
        <q-input
          v-model="endereco.rua"
          label="Rua"
          filled
          dense
          :rules="[(val) => !!val || 'Informe a rua']"
        />
        <q-input
          v-model="endereco.numero"
          label="Número"
          filled
          dense
          :rules="[(val) => !!val || 'Informe o número']"
        />
        <q-input
          v-model="endereco.bairro"
          label="Bairro"
          filled
          dense
          :rules="[(val) => !!val || 'Informe o bairro']"
        />
        <q-input
          v-model="endereco.cidade"
          label="Cidade"
          filled
          dense
          :rules="[(val) => !!val || 'Informe a cidade']"
        />
        <q-input
          v-model="endereco.cep"
          label="CEP"
          filled
          dense
          mask="#####-###"
          :rules="[(val) => !!val || 'Informe o CEP']"
        />
      </div>

      <q-select
        v-model="pagamento"
        :options="[
          { label: 'Dinheiro', value: 'dinheiro' },
          { label: 'Cartão', value: 'cartao' },
          { label: 'Pix', value: 'pix' },
        ]"
        label="Forma de pagamento"
        filled
        dense
        class="q-mb-md"
        :rules="[(val) => !!val || 'Escolha a forma de pagamento']"
        option-value="value"
        option-label="label"
        emit-value
        map-options
      />

      <q-separator class="q-my-md" />

      <div class="text-h6 q-mb-sm">Resumo do Pedido</div>
      <q-list bordered>
        <q-item v-for="(item, index) in carrinho" :key="index">
          <q-item-section>
            {{ item.nome }} <span v-if="item.quantidade">x{{ item.quantidade }}</span>
          </q-item-section>
          <q-item-section side>
            R$ {{ (item.preco * (item.quantidade || 1)).toFixed(2) }}
          </q-item-section>
        </q-item>
        <q-item>
          <q-item-section><strong>Total</strong></q-item-section>
          <q-item-section side
            ><strong>R$ {{ total.toFixed(2) }}</strong></q-item-section
          >
        </q-item>
      </q-list>

      <q-btn
        type="submit"
        label="Confirmar Pedido"
        color="positive"
        icon="check_circle"
        class="q-mt-lg"
        unelevated
        :disable="carrinho.length === 0"
      />
    </q-form>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()

const nome = ref('')
const telefone = ref('')
const pagamento = ref(null)
const entrega = ref('Retirada na loja')
const cpf = ref('')

const endereco = ref({
  rua: '',
  numero: '',
  bairro: '',
  cidade: '',
  cep: '',
})

const carrinho = ref([])
const nomeBloqueado = ref(true)
const mensagemCliente = ref('')
const clienteEncontrado = ref(true)

onMounted(() => {
  const salvo = localStorage.getItem('carrinho')
  carrinho.value = salvo ? JSON.parse(salvo) : []
})

const funcionarioId = 6 // fixe ou pegue do usuário logado
const clienteId = ref(null) // vamos atribuir ao buscar cliente

// Ajustar buscarCliente para salvar o clienteId:
const buscarCliente = async () => {
  const cpfLimpo = cpf.value.replace(/\D/g, '')
  if (cpfLimpo.length === 11) {
    try {
      const res = await axios.get(`http://localhost:3000/clientes/cpf/${cpfLimpo}`)
      if (res.data && res.data.nome) {
        nome.value = res.data.nome
        telefone.value = res.data.telefone
        clienteEncontrado.value = true
        mensagemCliente.value = '✅ Cliente localizado com sucesso.'
        clienteId.value = res.data.id // Salva o ID do cliente aqui
        nomeBloqueado.value = true // Bloqueia o campo nome
      }
    } catch (err) {
      if (err.response?.status === 404) {
        clienteEncontrado.value = false
        mensagemCliente.value = '⚠️ Cliente não localizado. Deseja cadastrar?'
        clienteId.value = null
      } else {
        console.error('Erro ao buscar cliente:', err)
        clienteEncontrado.value = false
        mensagemCliente.value = '⚠️ Erro na busca. Verifique a conexão com o servidor.'
        clienteId.value = null
      }
    }
  }
}

// Adaptar enviarPedido para usar os dados corretos:
const enviarPedido = async () => {
  if (!clienteId.value) {
    alert('Informe um cliente válido para finalizar o pedido.')
    return
  }

  if (entrega.value === 'Entrega em domicílio' && Object.values(endereco.value).some((v) => !v)) {
    alert('Preencha todos os campos de endereço.')
    return
  }

  try {
    // Monta os itens para enviar ao backend
    const itens = carrinho.value.map((item) => ({
      produto_id: item.id,
      quantidade: item.quantidade || 1,
      preco_unitario: item.preco,
    }))

    const corpo = {
      cliente_id: clienteId.value,
      funcionario_id: funcionarioId,
      pagamento: pagamento.value,
      desconto: 0, // ajustar se quiser
      itens,
      entrega: entrega.value,
      endereco: entrega.value === 'Entrega em domicílio' ? JSON.stringify(endereco.value) : null,
    }

    await axios.post('http://localhost:3000/vendas', corpo)

    alert('Pedido confirmado! Obrigado, ' + nome.value)
    localStorage.removeItem('carrinho')
    router.push('/vitrine')
  } catch (error) {
    console.error('Erro ao enviar pedido:', error)
    alert('Erro ao finalizar pedido')
  }
}

const total = computed(() =>
  carrinho.value.reduce((soma, item) => soma + item.preco * (item.quantidade || 1), 0),
)
</script>
