<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">🛒 Meu Carrinho</div>

    <div v-if="carrinho.length === 0" class="text-subtitle1 text-grey-7">
      Seu carrinho está vazio.
    </div>

    <q-list v-else bordered separator>
      <q-item v-for="(item, index) in carrinho" :key="index">
        <q-item-section>
          <q-item-label
            ><strong>{{ item.nome }}</strong></q-item-label
          >
          <q-item-label caption>
            R$ {{ item.preco.toFixed(2) }} x {{ item.quantidade }}
          </q-item-label>
          <q-input
            type="number"
            dense
            filled
            label="Quantidade"
            v-model.number="item.quantidade"
            @update:model-value="atualizarCarrinho"
            style="max-width: 120px"
            min="1"
          />
        </q-item-section>
        <q-item-section side>
          <q-btn flat icon="delete" color="negative" @click="removerDoCarrinho(index)" />
        </q-item-section>
      </q-item>
    </q-list>

    <div v-if="carrinho.length > 0" class="q-mt-lg">
      <div class="text-h6">Total: R$ {{ total.toFixed(2) }}</div>

      <q-btn
        label="Finalizar Pedido"
        color="positive"
        icon="check"
        class="q-mt-md"
        @click="finalizarPedido"
      />
    </div>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const carrinho = ref([])

onMounted(() => {
  const salvo = localStorage.getItem('carrinho')
  carrinho.value = salvo ? JSON.parse(salvo) : []
})

// Se algum item não tiver quantidade, define como 1
carrinho.value.forEach((item) => {
  if (!item.quantidade || item.quantidade < 1) item.quantidade = 1
})

const total = computed(() =>
  carrinho.value.reduce((soma, item) => soma + item.preco * item.quantidade, 0),
)

const atualizarCarrinho = () => {
  localStorage.setItem('carrinho', JSON.stringify(carrinho.value))
}

//const total = computed(() => carrinho.value.reduce((soma, item) => soma + item.preco, 0))

const removerDoCarrinho = (index) => {
  carrinho.value.splice(index, 1)
  localStorage.setItem('carrinho', JSON.stringify(carrinho.value))
}

const finalizarPedido = () => {
  alert('Pedido Enviado! Favor finalizar a compra.')
  carrinho.value = []
  //localStorage.removeItem('carrinho')
  router.push('/checkout') // Redireciona para a página de checkout
}
</script>
