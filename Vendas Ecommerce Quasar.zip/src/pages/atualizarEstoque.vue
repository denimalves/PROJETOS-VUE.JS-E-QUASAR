<template>
  <q-page class="q-pa-md">
    <q-card class="q-pa-md" style="max-width: 500px; margin: auto">
      <q-card-section>
        <div class="text-h6">Atualizar Estoque</div>
      </q-card-section>

      <q-card-section class="q-gutter-md">
        <q-select
          v-model="form.id"
          :options="produtos"
          option-label="nome"
          option-value="id"
          label="Selecione o Produto"
          filled
          emit-value
          map-options
        />
        <div v-if="estoqueAtual !== null">
          Estoque atual: <strong>{{ estoqueAtual }}</strong>
        </div>
        <q-input v-model.number="form.estoque" label="Quantidade de Entrada" type="number" filled />
        <q-btn label="Atualizar Estoque" color="primary" @click="atualizarEstoque" />
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'
import { useQuasar } from 'quasar'
import { api } from 'boot/axios'

const $q = useQuasar()
const produtos = ref([])
const estoqueAtual = ref(null)

const form = ref({
  id: null,
  estoque: null,
})

onMounted(async () => {
  const res = await api.get('/produtos')
  produtos.value = res.data
})

watch(
  () => form.value.id,
  (novoId) => {
    const produto = produtos.value.find((p) => p.id === novoId)
    estoqueAtual.value = produto ? produto.estoque : null
  },
)

async function atualizarEstoque() {
  if (!form.value.id || !form.value.estoque) {
    return $q.notify({ type: 'warning', message: 'Preencha todos os campos' })
  }
  try {
    await api.post('/estoque/entrada/:id', form.value)
    $q.notify({ type: 'positive', message: 'Estoque atualizado com sucesso' })
    form.value.estoque = null
    const atualizaProdutos = await api.get('/produtos')
    produtos.value = atualizaProdutos.data
    estoqueAtual.value = produtos.value.find((p) => p.id === form.value.id)?.estoque || 0
  } catch {
    $q.notify({ type: 'negative', message: 'Erro ao atualizar estoque' })
  }
}
</script>
