<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">🛒 Loja Online</div>

    <q-input
      v-model="busca"
      filled
      dense
      debounce="300"
      placeholder="Buscar produto..."
      class="q-mb-md"
      clearable
    />

    <q-btn
      color="primary"
      icon="shopping_cart"
      label="Ver Carrinho"
      class="q-mb-md"
      @click="irParaCarrinho"
    />

    <q-separator class="q-my-md" />

    <div class="row q-col-gutter-md">
      <q-card
        v-for="produto in produtosFiltrados"
        :key="produto.id"
        class="col-xs-12 col-sm-6 col-md-4 col-lg-3"
        bordered
        flat
      >
        <q-img :src="produto.imagem" ratio="4/3" />

        <q-card-section>
          <div class="text-subtitle1">{{ produto.nome }}</div>
          <div class="text-subtitle2 text-positive">
            {{ formatarPreco(produto.preco) }}
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn
            color="primary"
            icon="add_shopping_cart"
            @click="abrirDialogQuantidade(produto)"
            label="Comprar"
          />
        </q-card-actions>
      </q-card>
    </div>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { useQuasar } from 'quasar'

const router = useRouter()
const $q = useQuasar()

const produtos = ref([])
const busca = ref('')
const carrinho = ref([])

// Computa lista filtrada
const produtosFiltrados = computed(() => {
  const termo = busca.value.toLowerCase()
  return termo ? produtos.value.filter((p) => p.nome.toLowerCase().includes(termo)) : produtos.value
})

// Formata preço como R$ xx,xx
const formatarPreco = (valor) => `R$ ${valor.toFixed(2)}`

// Carrega os produtos da API
const buscarProdutos = async () => {
  try {
    const { data } = await axios.get('http://localhost:3000/produtos')
    produtos.value = data
  } catch (error) {
    console.error('Erro ao buscar produtos:', error)
  }
}

// Adiciona ao carrinho com dialog de quantidade
const abrirDialogQuantidade = (produto) => {
  $q.dialog({
    title: 'Quantidade',
    message: `Quantas unidades de "${produto.nome}" você deseja?`,
    prompt: {
      model: '1',
      type: 'number',
      isValid: (val) => val > 0,
      attrs: { min: 1 },
    },
    cancel: true,
    persistent: true,
  }).onOk((quantidadeStr) => {
    const quantidade = parseInt(quantidadeStr)

    const item = carrinho.value.find((p) => p.id === produto.id)

    if (item) {
      item.quantidade += quantidade
    } else {
      carrinho.value.push({ ...produto, quantidade })
    }

    localStorage.setItem('carrinho', JSON.stringify(carrinho.value))

    $q.notify({
      type: 'positive',
      message: `Adicionado ${quantidade}x ${produto.nome} ao carrinho!`,
    })
  })
}

// Vai para a rota do carrinho
const irParaCarrinho = () => router.push('/carrinho')

// Inicializa dados ao montar
onMounted(() => {
  buscarProdutos()
  const salvo = localStorage.getItem('carrinho')
  carrinho.value = salvo ? JSON.parse(salvo) : []
})
</script>
