<template>
  <q-page class="q-pa-md">
    <div class="text-h5 q-mb-md">🚚 Entregas em Domicílio</div>

    <q-table :rows="entregas" :columns="colunas" row-key="id" flat bordered>
      <!-- Status separado -->
      <template v-slot:body-cell-statusEntrega="props">
        <q-td>
          <q-badge :color="props.row.statusEntrega === 'Entregue' ? 'green' : 'orange'" align="top">
            {{ props.row.statusEntrega }}
          </q-badge>
        </q-td>
      </template>

      <!-- Botão na coluna Ação -->
      <template v-slot:body-cell-acao="props">
        <q-td class="text-center">
          <q-btn
            icon="check"
            color="primary"
            label="Confirmar Entrega"
            @click="confirmarEntrega(props.row)"
            dense
            flat
            rounded
            :disable="props.row.statusEntrega === 'Entregue'"
          />
        </q-td>
      </template>
    </q-table>

    <!-- Diálogo de confirmação -->
    <q-dialog v-model="dialogoConfirmar">
      <q-card>
        <q-card-section class="text-h6"> Confirmar entrega? </q-card-section>

        <q-card-section>
          Você tem certeza que deseja marcar esta entrega como <b>Entregue</b>?
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" v-close-popup />
          <q-btn color="primary" flat label="Confirmar" @click="confirmarAtualizacao" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const entregas = ref([])
const entregaSelecionada = ref(null)
const dialogoConfirmar = ref(false)

const colunas = [
  { name: 'id', label: 'ID', align: 'left', field: 'id' },
  {
    name: 'data',
    label: 'Data',
    align: 'left',
    field: (row) => row.data_venda.split(' ')[0].split('-').reverse().join('/'),
    sortable: true,
  },
  { name: 'cliente', label: 'Cliente', align: 'left', field: 'cliente' },
  { name: 'funcionario', label: 'Funcionário', align: 'left', field: 'funcionario' },
  { name: 'pagamento', label: 'Pagamento', align: 'left', field: 'pagamento' },
  { name: 'rua', label: 'Rua', align: 'left', field: 'rua' },
  { name: 'numero', label: 'Número', align: 'left', field: 'numero' },
  { name: 'bairro', label: 'Bairro', align: 'left', field: 'bairro' },
  { name: 'cidade', label: 'Cidade', align: 'left', field: 'cidade' },
  { name: 'statusEntrega', label: 'Status', align: 'left', field: 'statusEntrega' },
  { name: 'acao', label: 'Ação', align: 'center', sortable: false }, // SEM field!
]

const carregarEntregas = async () => {
  try {
    const res = await axios.get('http://localhost:3000/entregas')
    entregas.value = res.data.map((item) => {
      let enderecoParsed = {}
      try {
        enderecoParsed =
          typeof item.endereco === 'string' ? JSON.parse(item.endereco) : item.endereco
      } catch {
        console.warn('Endereço inválido:', item.endereco)
      }

      return {
        ...item,
        ...enderecoParsed,
        endereco: enderecoParsed,
      }
    })
  } catch (err) {
    console.error('Erro ao carregar entregas:', err)
  }
}

const confirmarEntrega = (row) => {
  entregaSelecionada.value = row
  dialogoConfirmar.value = true
}

const confirmarAtualizacao = async () => {
  try {
    await axios.put(`http://localhost:3000/entregas/${entregaSelecionada.value.id}/status`, {
      statusEntrega: 'Entregue',
    })
    entregaSelecionada.value.statusEntrega = 'Entregue'
    dialogoConfirmar.value = false
  } catch (err) {
    console.error('Erro ao atualizar status:', err)
  }
}

onMounted(() => {
  carregarEntregas()
})
</script>
