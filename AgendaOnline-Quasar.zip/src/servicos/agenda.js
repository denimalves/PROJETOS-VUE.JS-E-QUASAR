import useApi from 'src/composables/UseApi.js'

export default function agendaServicos() {
  const { listar, inserir, atualizar, excluir, getById } = useApi('agendamentos')
  return { listar, inserir, atualizar, excluir, getById }
}
