<template>
  <q-page
    style="
      backdrop-filter: blur(8px);
      background-color: rgba(255, 255, 255, 0.3);
      border-radius: 12px;
      padding: 20px;
    "
  >
    <h1 class="text-h4 text-primary text-center q-mb-md">Bem-vindo ao sistema de agendamentos</h1>

    <p class="text-subtitle1 text-center q-mb-sm">
      Este aplicativo foi desenvolvido para facilitar o agendamento de eventos de forma rápida,
      organizada e eficiente.
    </p>

    <p class="text-caption text-center text-grey-7">
      Fique atento às novidades — em breve, novas funcionalidades e atualizações estarão
      disponíveis!
    </p>
  </q-page>
</template>

<script setup>
//
</script>
