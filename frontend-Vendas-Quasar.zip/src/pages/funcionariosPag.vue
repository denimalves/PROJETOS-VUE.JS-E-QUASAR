<template>
  <q-page class="q-pa-md">
    <q-btn label="Adicionar Funcionário" color="primary" @click="adicionarFuncionario" />
    <q-table :rows="funcionarios" :columns="columns" row-key="id" class="q-mt-md">
      <template #body-cell-acoes="props">
        <q-td :props="props" class="q-gutter-x-sm">
          <q-btn dense round color="primary" icon="edit" @click="editarFuncionario(props.row)" />
          <q-btn
            dense
            round
            color="negative"
            icon="delete"
            @click="deletarFuncionario(props.row.id)"
          />
        </q-td>
      </template>
    </q-table>
    <q-dialog v-model="dialogAtivo">
      <funcionariosForm
        :funcionario="form"
        :modoEdicao="modoEdicao"
        @salvar="salvar"
        @cancelar="dialogAtivo = false"
      />
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from 'boot/axios'
import funcionariosForm from 'components/funcionariosForm.vue'

const dialogAtivo = ref(false) // mesmo diálogo p/ adicionar ou editar
const modoEdicao = ref(false) // false = novo | true = edição

const funcionarios = ref([])
const form = ref({
  id: null,
  nome: '',
  cargo: '',
})
const columns = [
  { name: 'id', label: 'ID', field: 'id' },
  { name: 'nome', label: 'Nome', field: 'nome' },
  { name: 'cargo', label: 'Cargo', field: 'cargo' },
  { name: 'acoes', label: 'Ações', field: 'acoes', align: 'center' },
]

async function carregarFuncionarios() {
  const res = await api.get('/funcionarios')
  funcionarios.value = res.data
}

async function adicionarFuncionario() {
  modoEdicao.value = false
  form.value = { id: null, nome: '', cargo: '' }
  dialogAtivo.value = true
}

function editarFuncionario(row) {
  modoEdicao.value = true
  form.value = { ...row } // clona dados da linha
  dialogAtivo.value = true
}

async function deletarFuncionario(id) {
  if (confirm('Tem certeza que deseja excluir?')) {
    await api.delete(`/funcionarios/${id}`)
    await carregarFuncionarios()
  }
}

async function salvar(dados) {
  try {
    if (modoEdicao.value) {
      await api.put(`/funcionarios/${dados.id}`, dados)
    } else {
      await api.post('/funcionarios', dados)
    }
    dialogAtivo.value = false
    await carregarFuncionarios()
  } catch (err) {
    console.error('Erro ao salvar funcionário:', err)
    alert('Erro ao salvar')
  }
}

onMounted(carregarFuncionarios)
</script>
