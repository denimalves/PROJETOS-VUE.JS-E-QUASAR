<template>
  <q-page>
    <h3>BEM VINDO</h3>
    <h5>SISTEMA EM MANUTENÇÃO</h5>
    <p>Funcionalidades CRUD ativadas e tela de vendas.</p>
    <p>Em andamento controle de acesso as telas por login</p>
  </q-page>
</template>

<script setup>
//
</script>
