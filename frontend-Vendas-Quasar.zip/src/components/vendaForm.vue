<template>
  <div class="q-gutter-md">
    <q-select
      filled
      dense
      v-model="venda.cliente_id"
      :options="props.clientes.map((c) => ({ label: c.nome, value: c.id }))"
      label="Cliente"
    />

    <q-select
      filled
      dense
      v-model="venda.funcionario_id"
      :options="props.funcionarios.map((f) => ({ label: f.nome, value: f.id }))"
      label="Funcionário"
    />

    <!-- Lista de itens -->
    <div v-for="i in venda.itens" :key="i.key" class="row q-col-gutter-md">
      <div class="col-5">
        <q-select
          filled
          dense
          v-model="i.produto_id"
          :options="props.produtos.map((p) => ({ label: p.nome, value: p.id }))"
          label="Produto"
        />
      </div>
      <div class="col-2">
        <q-input type="number" min="1" filled dense v-model.number="i.quantidade" label="Qtd" />
      </div>
      <div class="col-3">
        <q-input
          type="number"
          step="0.01"
          filled
          dense
          v-model.number="i.preco_unitario"
          label="Preço (R$)"
        />
      </div>
      <div class="col-2 flex flex-center">
        <q-btn flat dense icon="delete" color="negative" @click="removerItem(i.key)" />
      </div>
    </div>

    <q-btn flat dense icon="add" label="Adicionar item" @click="adicionarItem" />

    <q-input
      type="number"
      step="0.01"
      filled
      dense
      v-model.number="venda.desconto"
      label="Desconto (R$)"
    />

    <q-select
      filled
      dense
      v-model="venda.pagamento"
      :options="[
        { label: 'Dinheiro', value: 'dinheiro' },
        { label: 'Cartão', value: 'cartao' },
        { label: 'Pix', value: 'pix' },
      ]"
      label="Forma de pagamento"
    />

    <div class="text-right text-h6 q-mt-sm">Total: R$ {{ totalLiquido.toFixed(2) }}</div>

    <q-btn color="primary" label="Salvar Venda" @click="enviar" />
  </div>
</template>

<style scoped>
.row {
  align-items: center;
}
</style>

<script setup>
import { ref, computed, watch } from 'vue'
import { uid, useQuasar } from 'quasar'

const props = defineProps({
  funcionarios: { type: Array, default: () => [] },
  clientes: { type: Array, default: () => [] },
  produtos: { type: Array, default: () => [] },
})
const emit = defineEmits(['salvar'])
const $q = useQuasar()

// Modelo principal
const venda = ref({
  cliente_id: null,
  funcionario_id: null,
  pagamento: 'dinheiro',
  desconto: 0,
  itens: [],
})

// Adiciona item em branco
function adicionarItem() {
  venda.value.itens.push({
    key: uid(), // chave p/ repetição no template
    produto_id: null,
    quantidade: 1,
    preco_unitario: 0,
  })
}

function removerItem(key) {
  venda.value.itens = venda.value.itens.filter((i) => i.key !== key)
}

// Recalcula preço unitário quando produto é escolhido
watch(
  () => venda.value.itens.map((i) => i.produto_id),
  () => {
    venda.value.itens.forEach((item) => {
      if (item.produto_id) {
        const p = props.produtos.find((p) => p.id === item.produto_id)
        if (p) item.preco_unitario = p.preco
      }
    })
  },
)

const totalBruto = computed(() =>
  venda.value.itens.reduce((s, i) => s + i.quantidade * i.preco_unitario, 0),
)
const totalLiquido = computed(() => totalBruto.value - (Number(venda.value.desconto) || 0))

function enviar() {
  // Validação mínima
  if (!venda.value.cliente_id || !venda.value.funcionario_id) {
    return $q.notify({ type: 'warning', message: 'Selecione cliente e funcionário' })
  }
  if (venda.value.itens.length === 0) {
    return $q.notify({ type: 'warning', message: 'Adicione ao menos um item' })
  }

  // Payload limpo (remove keys internas)
  const payload = {
    ...venda.value,
    itens: venda.value.itens.map(({ produto_id, quantidade, preco_unitario }) => ({
      produto_id,
      quantidade,
      preco_unitario,
    })),
  }
  emit('salvar', payload)
  // opcional: resetar formulário
  Object.assign(venda.value, {
    cliente_id: null,
    funcionario_id: null,
    pagamento: 'dinheiro',
    desconto: 0,
    itens: [],
  })
}

// Inicializa com uma linha
adicionarItem()
</script>
